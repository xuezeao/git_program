#ifndef DATANOUPDATE_H
#define DATANOUPDATE_H

class DataNoUpdate
{
public:
    DataNoUpdate();
};

#endif // DATANOUPDATE_H
