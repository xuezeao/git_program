#include "datanoupdate.h"

DataNoUpdate::DataNoUpdate()
{
}
