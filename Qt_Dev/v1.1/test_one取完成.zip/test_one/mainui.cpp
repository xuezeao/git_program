#include "mainui.h"
#include "ui_mainui.h"

MainUI::MainUI(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainUI)
{
    ui->setupUi(this);
    MainUi_http_Page = new http_GAndP;
    MainUi_operate_Page = new OperateWindow;

    MainUi_http_Page->getHttp();

    connect(MainUi_operate_Page,SIGNAL(OperateWindow_To_MainUI()),this,SLOT(closeOperatePage_Return_MainUi()));

}

MainUI::~MainUI()
{
    delete ui;
}

void MainUI::on_pushButton_clicked()
{
    MainUi_http_Page->getHttp();
}


void MainUI::on_pushButton_2_clicked()
{
    MainUi_http_Page->postHttp(0,"0");
}

void MainUI::on_pBT_PutIn_clicked()
{
    MainUi_operate_Page->show();
    MainUi_operate_Page->ModelSelect(1);
    this->close();
}


void MainUI::closeOperatePage_Return_MainUi()
{
    this->show();
    MainUi_operate_Page->close();
}


void MainUI::on_pBt_Get_clicked()
{
    MainUi_operate_Page->show();
    MainUi_operate_Page->ModelSelect(2);
    this->close();
}
