 #include "agentiainfochange.h"
#include "ui_agentiainfochange.h"
#include <QRegExp>
#include <QValidator>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QDebug>

AgentiaInfoChange::AgentiaInfoChange(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AgentiaInfoChange)
{
    ui->setupUi(this);
   /* setWindowTitle(QString("信息修改界面"));//标题
    setWindowFlags(windowFlags()&~(Qt::WindowMinimizeButtonHint|Qt::WindowMaximizeButtonHint|Qt::WindowCloseButtonHint));
    //最大化等按钮无效化*/
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏

//    QRegExp regx_bottleCapacity("");//"[a-zA-Z0-9]+$" 长度7纯数字输入3.3格式
//    QValidator *validator_bottleCapacity = new QRegExpValidator(regx_bottleCapacity,ui->lineEdit_does);
//    ui->lineEdit_does->setValidator(validator_bottleCapacity);

//    QRegExp regx_does("");//"[a-zA-Z0-9]+$" 长度7纯数字输入3.3格式
//    QValidator *validator_dose = new QRegExpValidator(regx_does,ui->lineEdit_does);
//    ui->lineEdit_does->setValidator(validator_dose);

    QRegExp regx_date("[0-9]{1,4}[.][0-9]{1,2}[.][0-9]{1,2}");
    QValidator *validator_date = new QRegExpValidator(regx_date,ui->lineEdit_expireDate);
    ui->lineEdit_expireDate->setValidator(validator_date);







}

void AgentiaInfoChange::closeWindow_operate()
{

    addInfo_To_sheet(AInfo_sheetOrder);
    emit upSheet_PutIn();
    this->close();
}

void AgentiaInfoChange::sendUP_Info(int status ,int OK_Push, int sheetOrder)//选择显示的模式 //0 集体修改；1 单个修改
{

    AInfo_OK_Push = OK_Push;
    AInfo_sheetOrder = 0;
    changeShowInfo(0);//从第一条开始执行
    if(status == 1)
    {
        ui->pBt_nextOperate->setText("完成");
        ui->pBt_previousOperate->setText("上一条");
        ui->pBt_previousOperate->setEnabled(false);
        AInfo_sheetOrder = sheetOrder;

        changeShowInfo(sheetOrder);
    }
    else{
        ui->pBt_nextOperate->setText("下一条");
        ui->pBt_previousOperate->setText("完成");
        ui->pBt_previousOperate->setEnabled(true);
    }



}

AgentiaInfoChange::~AgentiaInfoChange()
{
    delete ui;

}

void AgentiaInfoChange::on_pBt_returnPrevious_clicked()
{

    closeWindow_operate();
}

void AgentiaInfoChange::on_pBt_nextOperate_clicked()
{
    QSqlQuery query;
    query.exec(QString("select * from T_Task_PutIn"));
    query.last();//定位到最后一条
    int rowNum = query.at();//获取 rowNum

    if((AInfo_OK_Push == 1) || (AInfo_sheetOrder >= rowNum && AInfo_OK_Push == 0))
    {

        closeWindow_operate();

    }else{

        if(AInfo_sheetOrder < rowNum)
        {
            addInfo_To_sheet(AInfo_sheetOrder);
            AInfo_sheetOrder++;
            changeShowInfo(AInfo_sheetOrder);
            ui->pBt_previousOperate->setText("上一步");
            AInfo_OK_Push = 0;
        }
        if(AInfo_sheetOrder >= rowNum)
        {
            ui->pBt_nextOperate->setText("完成");
            AInfo_OK_Push = 1;
            AInfo_sheetOrder = rowNum;

        }
    }



    qDebug()<<"AInfo_Sheet: "<<AInfo_sheetOrder;
}



void AgentiaInfoChange::on_pBt_previousOperate_clicked()
{

    if((AInfo_OK_Push == 2) || (AInfo_sheetOrder <= 0 && AInfo_OK_Push == 0))
    {

        closeWindow_operate();
    }else{
        if(AInfo_sheetOrder > 0)
        {
            addInfo_To_sheet(AInfo_sheetOrder);
            AInfo_sheetOrder--;
            changeShowInfo(AInfo_sheetOrder);
            ui->pBt_nextOperate->setText("下一步");
            AInfo_OK_Push = 0;
        }
        if(AInfo_sheetOrder <= 0)//为0的时候切换为完成功能
        {
            ui->pBt_previousOperate->setText("完成");
            AInfo_OK_Push = 2;
        }
    }





    qDebug()<<"AInfo_Sheet: "<<AInfo_sheetOrder\
              <<"OK: "<< AInfo_OK_Push;


}


void AgentiaInfoChange::addInfo_To_sheet(int i)
{
    QString getC_bottleCapacity = ui->lineEdit_bottleCapacity->text();
    QString getC_dose = ui->lineEdit_does->text();
    QString getC_expireDate = ui->lineEdit_expireDate->text();
    QString getC_drawerSize = ui->comboBox_drawerSize->currentText();

    QSqlQuery query;

    query.exec(QString("update T_Task_PutIn set bottleCapacity='%1',dose='%2',\
                       drawerSize='%3',expireDate='%4' where rowid=%5")
               .arg(getC_bottleCapacity).arg(getC_dose).arg(getC_drawerSize).arg(getC_expireDate).arg(i+1));//rowid 从1开始

    query.exec(QString("select * from T_Task_PutIn"));
    query.seek(0);

   /*  getC_bottleCapacity = query.value(4).toString();//额定容量
     getC_dose = query.value(5).toString();//实际容量
     getC_expireDate = query.value(7).toString();//失效日期
     getC_drawerSize = query.value(6).toString();//规格

    qDebug()<<getC_bottleCapacity<<"    "<<
              getC_dose<<"     "<<getC_expireDate<<"       "
              <<getC_drawerSize;
*/
}

void AgentiaInfoChange::changeShowInfo(int i)
{
    QSqlQuery query;
    query.exec(QString("select * from T_Task_PutIn"));
    query.seek(i);

    QString getC_AName = query.value(3).toString();//试剂名
    int getC_Attribute = query.value(9).toInt();//试剂类别
    int getC_ID = query.value(10).toInt();//试剂ID
    QString getC_LFormula = query.value(11).toString();//化学式
    QString getC_Specification = query.value(12).toString();//详细介绍
    QString getC_Factory = query.value(13).toString();//厂商
    QString getC_ItemNo = query.value(14).toString();//项目编号

    QString getC_bottleCapacity = query.value(4).toString();//额定容量
    QString getC_dose = query.value(5).toString();//实际容量
    QString getC_expireDate = query.value(7).toString();//失效日期
    QString getC_drawerSize = query.value(6).toString();//规格



    ui->lineEdit_bottleCapacity->setText(getC_bottleCapacity);
    ui->lineEdit_does->setText(getC_dose);
    ui->lineEdit_expireDate->setText(getC_expireDate);
    ui->comboBox_drawerSize->setCurrentText(getC_drawerSize);


    ui->label_agentiaName->setText(getC_AName);
    ui->label_chemicalFormula->setText(getC_LFormula);
    ui->textBrowser_specification->setText(getC_Specification);
    ui->label_factory->setText(getC_Factory);
    ui->label_attribute->setText(QString("%1").arg(getC_Attribute));
    ui->label_agentiaID->setText(QString("%1").arg(getC_ID));
    ui->label_itemNo->setText(getC_ItemNo);

    /*
     * query.next();//执行一次next，quer指向结果集的第一条记录
      query.seek(2);//定位到编号为2的记录，即第三条记录
      query.last();//定位到最后一条记录
      int rowNum = query.at();//获取 rowNum
      int columnNum = query.record().count();//获取 column
      int fieldNo = query.record().indexOf("agentiaName");//获取所在列的编号，从左向右，0
      int getC_AName = query.value(0).toString();//获取值

    /*query.prepare("update T_Task_PutIn set bottleCapacity = ?,dose = ?,drawerSize = ?,expireDate = ? where id = ?");
    query.addBindValue(getC_bottleCapacity);
    query.addBindValue(getC_dose);
    query.addBindValue(getC_drawerSize );
    query.addBindValue(getC_expireDate);
    query.addBindValue(1);
    query.exec();*/

}
