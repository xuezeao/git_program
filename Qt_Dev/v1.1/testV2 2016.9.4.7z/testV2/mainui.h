#ifndef MAINUI_H
#define MAINUI_H

#include <QMainWindow>
#include "http_gandp.h"
#include "operatewindow.h"

#include <QByteArray>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QtDebug>
#include <QUrl>
#include <QtNetwork>
#include <QMessageBox>
namespace Ui {
class MainUI;
}

class MainUI : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainUI(QWidget *parent = 0);
    ~MainUI();



private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();



    void closeOperatePage_Return_MainUi();

    void on_pBT_PutIn_clicked();

private:
    Ui::MainUI *ui;
    http_GAndP *MainUi_http_Page;
    OperateWindow *MainUi_operate_Page;

};

#endif // MAINUI_H
