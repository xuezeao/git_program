#ifndef EXECUT_WINDOW_H
#define EXECUT_WINDOW_H

#include <QDialog>
#include "http_gandp.h"

namespace Ui {
class Execut_window;
}

class Execut_window : public QDialog
{
    Q_OBJECT

public:
    explicit Execut_window(QWidget *parent = 0);
    ~Execut_window();
     void executInit(int num);
private slots:
    void on_pBt_cancal_clicked();

    void on_pBt_jump_clicked();

    void on_pBt_next_clicked();

    bool executShow(int drawerNo,int positionNo);//等待服务器接收完成信号

    void executError(int num,QString error);//任务完成情况 0-error  1-OK

private:
    Ui::Execut_window *ui;
    http_GAndP *Execut_http_GAndP;



    void executOperate();


    struct Execut_Variable{
        int execut_model;
        int acountRow;
        QString T_executTable;

    }EXECUT;
    struct Execut_Variable *execut_V;
};

#endif // EXECUT_WINDOW_H
