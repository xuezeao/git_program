#ifndef OPERATEWINDOW_H
#define OPERATEWINDOW_H

#include "global_Vailable.h"
#include <QWidget>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include <QDebug>
#include <QSqlQuery>

#include <QCheckBox>
#include <QPushButton>

#include "execut_window.h"

namespace Ui {
class OperateWindow;
}

class OperateWindow : public QWidget
{
    Q_OBJECT

public:
    explicit OperateWindow(QWidget *parent = 0);
    ~OperateWindow();

    void ModelSelect(int num);//1-入柜

signals:
    void OperateWindow_To_MainUI();

private slots:
    void on_Bt_backBefore_clicked();

    void on_Bt_searchInfo_clicked();

    void on_Bt_execute_clicked();

    void on_Bt_delete_clicked();

    void on_Bt_add_clicked();

private:
    Ui::OperateWindow *ui;
    Execut_window *Operate_execut_Page;

    QSqlRelationalTableModel *T_model_PutIn;
    QSqlTableModel *T_model_Other_Search;
    QSqlTableModel *T_model_Other_Execut;

    QSqlQuery *query;

    QCheckBox *checkBox_S[ROW_ALLACOUNT];
    QPushButton *pushBt_S[ROW_ALLACOUNT];


    QCheckBox *checkBox_E[ROW_ALLACOUNT];
    QPushButton *pushBt_E[ROW_ALLACOUNT];

//    bool eventFilter(QObject *watched, QEvent *event);



    void tableInit();//初始化表格
    void widgetInit();//初始化部件

    struct T_Table{
        QString T_search_RelationTable;//搜索框关联表格
        QString T_execut_RelationTable;//执行框关联表格
        int     dialog_model;//区分模式
    }T_TABLE;

    struct T_Table *T_table;
};

#endif // OPERATEWINDOW_H
