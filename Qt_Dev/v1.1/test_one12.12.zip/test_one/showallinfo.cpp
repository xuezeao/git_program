#include "showallinfo.h"
#include "ui_showallinfo.h"
#include <qsqlquery.h>
#include <QDebug>
#include <QDesktopWidget>

ShowAllInfo::ShowAllInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ShowAllInfo)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
//    move((QApplication::desktop()->width()-this->width())/2,(QApplication::desktop()->height()-this->height())/2);//居中

    T_model_show = new QSqlTableModel;



}

ShowAllInfo::~ShowAllInfo()
{
    delete ui;
}
/*****************************************/
void ShowAllInfo::on_pBt_close_clicked()
{
    /***************清空表格************/
    QSqlQuery query;
    query.exec(QString("DELETE * from %1").arg(T_name));
    query.next();
    /********************************/
    this->close();

}

/******************************************/

void ShowAllInfo::showInfo(int order)//0：入柜 1：还
{
    if(order == 1)
    {
        T_name = "T_AgentiaWaitExecute";
        T_model_show->setTable(QString("%1").arg(T_name));
        T_model_show->select();
        T_model_show->setHeaderData(2,Qt::Horizontal,QObject::tr("试剂名"));
        T_model_show->setHeaderData(4,Qt::Horizontal,QObject::tr("试剂容量"));
        T_model_show->setHeaderData(9,Qt::Horizontal,QObject::tr("抽屉号"));
        T_model_show->setHeaderData(10,Qt::Horizontal,QObject::tr("位置"));
        T_model_show->setHeaderData(13,Qt::Horizontal,QObject::tr("状态"));

        T_model_show->setEditStrategy(QSqlTableModel::OnManualSubmit);

//        T_model_show->sort(9,Qt::AscendingOrder);//升序

        ui->tableView_showInfo->setModel(T_model_show);

        ui->tableView_showInfo->setColumnHidden(0,true);
        ui->tableView_showInfo->setColumnHidden(1,true);
        ui->tableView_showInfo->setColumnHidden(3,true);
        ui->tableView_showInfo->setColumnHidden(5,true);
        ui->tableView_showInfo->setColumnHidden(6,true);
        ui->tableView_showInfo->setColumnHidden(7,true);
        ui->tableView_showInfo->setColumnHidden(8,true);
        ui->tableView_showInfo->setColumnHidden(11,true);
        ui->tableView_showInfo->setColumnHidden(12,true);

        ui->tableView_showInfo->setEditTriggers(QAbstractItemView::NoEditTriggers);
    }
    else if(order == 0)
    {
        T_name = "T_Task_PutIn";
        T_model_show->setTable(QString("%1").arg(T_name));
        T_model_show->select();
        T_model_show->setHeaderData(3,Qt::Horizontal,QObject::tr("试剂名"));
        T_model_show->setHeaderData(5,Qt::Horizontal,QObject::tr("试剂容量"));
        T_model_show->setHeaderData(15,Qt::Horizontal,QObject::tr("状态"));

        T_model_show->setEditStrategy(QSqlTableModel::OnManualSubmit);

        ui->tableView_showInfo->setModel(T_model_show);

        ui->tableView_showInfo->setColumnHidden(0,true);
        ui->tableView_showInfo->setColumnHidden(1,true);
        ui->tableView_showInfo->setColumnHidden(2,true);
        ui->tableView_showInfo->setColumnHidden(4,true);
        ui->tableView_showInfo->setColumnHidden(6,true);
        ui->tableView_showInfo->setColumnHidden(7,true);
        ui->tableView_showInfo->setColumnHidden(8,true);
        ui->tableView_showInfo->setColumnHidden(9,true);
        ui->tableView_showInfo->setColumnHidden(10,true);
        ui->tableView_showInfo->setColumnHidden(11,true);
        ui->tableView_showInfo->setColumnHidden(12,true);
        ui->tableView_showInfo->setColumnHidden(13,true);
        ui->tableView_showInfo->setColumnHidden(14,true);



        ui->tableView_showInfo->setEditTriggers(QAbstractItemView::NoEditTriggers);
    }
}










