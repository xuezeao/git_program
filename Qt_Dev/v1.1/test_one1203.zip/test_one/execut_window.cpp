#include "execut_window.h"
#include "ui_execut_window.h"
#include <QSqlQuery>
#include <QPalette>
#include <QApplication>
#include <QDesktopWidget>

Execut_window::Execut_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Execut_window)
{
    ui->setupUi(this);

    Execut_http_GAndP = new http_GAndP;
    Show_Info = new ShowAllInfo;

  /*  setWindowTitle(QString("执行中"));//标题
    setWindowFlags(windowFlags()&~(Qt::WindowMinimizeButtonHint|Qt::WindowMaximizeButtonHint|Qt::WindowCloseButtonHint));
    //令最大化、最小化、关闭按钮失效*/
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
//    move((QApplication::desktop()->width()-this->width())/2,(QApplication::desktop()->height()-this->height())/2);//居中


    QRegExp regx_bottleCapacity("[0-9]+$");//"[a-zA-Z0-9]+$" 长度7纯数字输入3.3格式
    QValidator *validator_bottleCapacity = new QRegExpValidator(regx_bottleCapacity,ui->lineEdit_changeVolume);
    ui->lineEdit_changeVolume->setValidator(validator_bottleCapacity);


 
//    execut_V = &EXECUT;
    execute_V = new struct Execute_Variable;


    connect(Execut_http_GAndP,SIGNAL(sendInfo_To_Execut(int,int,int)),this,SLOT(executeShow(int,int,int)));
    connect(Execut_http_GAndP,SIGNAL(sendInfo_To_return(int)),this,SLOT(updateReturn(int)));
    connect(Execut_http_GAndP,SIGNAL(sendError_To_Execut(int,QString)),this,SLOT(executeInfoError(int,QString)));
    connect(Execut_http_GAndP,SIGNAL(sendFalse()),this,SLOT(NetworkError()));

}

void Execut_window::updateReturn(int status)//0 成功 1 失败 2 未放置
{
    QSqlQuery query;
    QString error;

    if(status == 0)
    {
        error = "上传成功";
    }
    else if(status == 1)
    {
        error = "上传失败";
    }
    else if(status == 2)
    {
        error = "未放置";
    }

    execute_V->httpCount++;
    query.exec(QString("update %1 set judgeAttitude='%2' where rowid=%3")
                   .arg(execute_V->T_executeTable).arg(QString(error)).arg(execute_V->httpCount));


    if(execute_V->httpCount -1 <= execute_V->acountRow)
    {
        http_PG_AgentiaInfo(3,execute_V->httpCount);
    }
    else
    {
        closePage();
    }


}

/****************************屏幕显示****************************************/
bool Execut_window::executeShow(int drawerNo,int positionNo,int positionId)//当http解析完系统反馈true才能继续执行
{
    positionId = execute_V->positionId;
    QSqlQuery query;
    QString show_Name;
    QString show_Volume;
    QString show_position;

    query.exec(QString("select * from %1")//从id=rownum中选中所有属性 '*' /也可指定 'name'
               .arg(execute_V->T_executeTable));
    query.seek(execute_V->currentAcount-1);

    show_Name = query.value(3).toString();
    show_Volume = query.value(4).toString();
    show_position = QString("抽屉：%1，位置：%2").arg(drawerNo).arg(positionNo);


    ui->lineEdit_Name->setText(show_Name);
    ui->lineEdit_Volume->setText(show_Volume);
    ui->lineEdit_Position->setText(show_position);

    ui->label_RoleStatus->setText("请放置药剂");




    execute_V->drawerNo = drawerNo;
    execute_V->positionNO = positionNo;

    SCI_send(0);
    if(execute_V->execute_model == 1)
    {
        ui->pBt_next->show();
    }
    return true;
}

int Execut_window::SCI_send(int order)//0:下发 1：查询 2：完成
{


    if(order == 0)
    {
       return true ;
    }
    else if(order == 1)
    {
        return true;
    }
    else if(order == 2)
    {
        return true;
    }

    return true;
}



/*************************按键区*************************************/



Execut_window::~Execut_window()
{
    delete ui;
}

void Execut_window::on_pBt_cancal_clicked()
{
    closePage();
}

void Execut_window::on_pBt_next_clicked()
{

    if(execute_V->pBt_status == 1)
    {
        execute_V->pBt_status = 2;
        pBt_operate(1);
        qDebug()<<" enter ";

    }
    ui->pBt_cancal->show();


}
void Execut_window::on_pBt_ignore_clicked()
{
    /**********跳过*********************/
    SCI_send(2);
    if(execute_V->execute_model == 1)
    {
          PutIn_info(2);
    }
    ui->pBt_ignore->hide();
    operateNext();
}


/********************自定函数区************************/

void Execut_window::executeInit(int num)
{
    switch (num) {
    case 1:{
        ui->label_title->setText("入柜");
        execute_V->T_executeTable="T_Task_PutIn";
        execute_V->execute_model = 1;
        ui->label_oddDose->hide();
        ui->label_changeNewAgentia->hide();
        ui->lineEdit_changeVolume->hide();
        ui->CMB_V->hide();
        ui->pBt_ignore->hide();
        break;
    }
    case 2:{
        ui->label_title->setText("归还");
        execute_V->T_executeTable="T_AgentiaWaitExecute";
        execute_V->execute_model = 2;
        ui->label_oddDose->show();
        ui->label_changeNewAgentia->show();
        ui->lineEdit_changeVolume->show();
        ui->CMB_V->show();
        ui->pBt_ignore->hide();
        break;
    }
    default:
        break;
    }

    initVariable();
}

void Execut_window::initVariable()
{
    execute_V->acountRow = 0;
    execute_V->currentAcount = 1;
    execute_V->pBt_status = 1;
    execute_V->orderPosition = 1;
    execute_V->httpCount = 0;
    execute_V->drawerAcount =1;
    ui->pBt_cancal->show();
    ui->pBt_next->show();

    getAllCount();

    if(execute_V->execute_model == 2)
    {
        if(saveDrawer[0] == 0)
        {
            this->close();
        }
        else{
           searchPositionInfo(execute_V->T_executeTable,saveDrawer[1]);
        }

    }
    pBt_operate(0);

}

void Execut_window::getAllCount()
{
    QSqlQuery query;
    int temporaryA = 0;
    int temporaryB = 0;
    int k = 0;
    saveDrawer[0] = 0;

    if(execute_V->execute_model == 1)
    {
        query.exec(QString("select * from T_Task_PutIn"));
        query.last();
        execute_V->acountRow = query.at();

    }
    else if(execute_V->execute_model == 2)
    {

        query.exec(QString("SELECT * from T_AgentiaWaitExecute ORDER BY drawerNo ASC"));

        query.last();
        execute_V->acountRow = query.at();


        for(int i = 0; i <= execute_V->acountRow; i++)
        {
            query.seek(i);
            temporaryA = query.value(9).toInt();
            if(temporaryA != temporaryB)
            {
                temporaryB = temporaryA;
                k++;
                saveDrawer[0]=k;
                saveDrawer[k]=temporaryB;
            }

        }

        if(saveDrawer[0] != 0)
        {
            searchPositionInfo(execute_V->T_executeTable,1);
            pBt_operate(0);
        }
        else
            qDebug()<<" NO Info !-------getAllCount";

    }
}

void Execut_window::searchPositionInfo(QString name,int i)//获取对应抽屉内的试剂rowid
{
    QSqlQuery query;
    int temporaryC = 0;
    query.exec(QString("select * from %1 where drawerNo=%2").arg(name).arg(saveDrawer[i]));


    query.last();
    temporaryC= query.at();

    for(int i = 0; i <= temporaryC ;i++)
    {
        query.seek(i);
        saveRowid[0] = i+1;
        saveRowid[i+1] = query.value(0).toInt();
//        qDebug()<<saveRowid[i+1]<<" ----------form searchPositionInfo"<<saveRowid[0];
    }


}

void Execut_window::getAgentiaPositionInfo(int i)//1：入柜 尺寸 2：还 位置
{


    if(execute_V->execute_model == 1)
    {
        http_PG_AgentiaInfo(1,i);

    }
    else if(execute_V->execute_model == 2)
    {
        QSqlQuery query;
        QString A_name;
        int A_Drawer;
        int A_Position;
        QString position;
        QString statusA,statusB,statusC;
        QString Volume;


        query.exec(QString("select * from %1 where rowid=%2").arg(execute_V->T_executeTable).arg(saveRowid[i]));
        query.next();

        A_name = query.value(2).toString();
        A_Drawer  = query.value(9).toInt();
        A_Position = query.value(10).toInt();
        Volume = query.value(4).toString();

        position = QString("抽屉号： %1,位置号: %2").arg(A_Drawer).arg(A_Position);

        updateShowInfo(A_name,Volume,position);

        statusA = query.value(6).toString();
        statusB = query.value(7).toString();
        statusC = query.value(8).toString();

        execute_V->positionNO = A_Position;
        execute_V->drawerNo   = A_Drawer;



        if(statusA == "归还")
        {
            ui->label_changeNewAgentia->setText("剩余：");
            SCI_send(0);
        }
        else if(statusB == "替换")
        {
            ui->label_changeNewAgentia->setText("替换为：");
            SCI_send(0);
        }
        else if(statusC == "报废")
        {
            changeAgentiaStatus(6,0);
            operateNext();
        }

    }

}

void Execut_window::updateShowInfo(QString A_name, QString Volume, QString Position)
{
   ui->lineEdit_Name->setText(A_name);
   ui->lineEdit_Position->setText(Position);
   ui->lineEdit_Volume->setText(Volume);
}

void Execut_window::http_PG_AgentiaInfo(int order, int i)// order 1: 入柜申请位置 2：入柜上传 3：还上传
{
    if(order == 1)
    {
        Execut_http_GAndP->jsonForSend(5,execute_V->T_executeTable,execute_V->currentAcount);//调用生成json信息 上报位置请求

    }
    else if(order == 2)
    {
        Execut_http_GAndP->jsonForSend(6,execute_V->T_executeTable,execute_V->currentAcount);//上报成功位置
    }
    else if(order == 3)
    {
        Execut_http_GAndP->jsonForSend(8,execute_V->T_executeTable,i);//试剂上报
    }
}

void Execut_window::pBt_operate(int order)//0：下一步 1：查询
{

    if(order == 0)
    {
        if(execute_V->currentAcount <= execute_V->acountRow+1)
        {


            if(execute_V->execute_model == 2)
            {
                if(execute_V->orderPosition <= saveRowid[0])
                {


                    getAgentiaPositionInfo(execute_V->orderPosition);
                }
                else
                {
                    if(execute_V->drawerAcount <= saveDrawer[0])
                    {
                        execute_V->orderPosition = 1;

                        execute_V->drawerAcount++;
                        searchPositionInfo(execute_V->T_executeTable,execute_V->drawerAcount);

                        pBt_operate(0);
                    }
                }
            }
            else if(execute_V->execute_model == 1)
            {
                ui->pBt_ignore->show();
                getAgentiaPositionInfo(1);
            }


        }
        else
        {
            if(execute_V->execute_model == 1)
            {
                closePage();
            }
            else if(execute_V->execute_model == 2)
            {
                http_PG_AgentiaInfo(3,0);
                ui->pBt_cancal->hide();
                ui->pBt_next->hide();
            }

        }

    }
    else if(order == 1)
    {

        int Error;//0: 错误 1：未完成 2：正确

        /***********查询***********/
        Error=SCI_send(1);
        Error = 0;
        /**********************/
        if(Error == 2)
        {

            SCI_send(2);
            executeInfoError(3,"操作正确，请下一个任务");
            if(execute_V->execute_model == 1)
            {

                http_PG_AgentiaInfo(2,0);
                changeAgentiaStatus(4,0);

            }
            else if(execute_V->execute_model == 2)
            {
                QString dose = ui->lineEdit_changeVolume->text();
                QString uint = ui->CMB_V->currentText();
                execute_V->newDose = dose+uint;
               /*****************需要加入弹窗提示*********************/


                /*************************************/
                changeAgentiaStatus(4,1);
                operateNext();
            }

        }
        else if(Error == 1)
        {
            ui->pBt_ignore->show();
            ui->pBt_cancal->show();

            executeInfoError(2,"是否跳过本次任务");
            changeAgentiaStatus(3,2);

        }
        else if(Error == 0)
        {
            executeInfoError(0,"错误，请更正！");
            changeAgentiaStatus(5,0);
            ui->pBt_cancal->hide();
        }

     execute_V->pBt_status = 1;
    }
}

void Execut_window::changeAgentiaStatus(int just , int order)
//更新试剂显示状态 1：上传成功 2：上传失败 3：未操作 4：正确操作 5：错误操作 6:报废操作
// order 1:正常 2：跳过
{
    QSqlQuery query;
    QString error;
    if(just == 1)
    {
        error = "上传成功";

    }else if(just == 2)
    {
        error = "上传失败";
    }else if(just == 3)
    {
        error = "未操作";
    }else if(just == 4)
    {
        error = "正确操作";
    }else if(just == 5)
    {
        error = "错误操作";
    }else if(just == 6)
    {
        error = "报废操作";
    }

    if(execute_V->execute_model == 1)
    {
        query.exec(QString("update %1 set judgeAttitude='%2' where rowid=%3")
                   .arg(execute_V->T_executeTable).arg(error).arg(execute_V->currentAcount));
    }
    else if(execute_V->execute_model == 2)
    {
        if(order == 1)
        {
            query.exec(QString("update %1 set judgeAttitude='%2',dose='%3' where rowid=%4")
                   .arg(execute_V->T_executeTable).arg(error).arg(execute_V->newDose).arg(saveRowid[execute_V->orderPosition]));

        }
        else if(order == 2)
        {
            query.exec(QString("update %1 set judgeAttitude='%2' where rowid=%3")
                   .arg(execute_V->T_executeTable).arg(error).arg(saveRowid[execute_V->orderPosition]));

        }
    }

}

void Execut_window::executeInfoError(int num, QString error)//输出任务状态并执行未成功数据保存
//任务完成情况 0-error  1-操作OK 2-跳过 3 显示OK
{

    if(num == 0)
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::red);
        ui->label_RoleStatus->setPalette(pe);

        if(execute_V->execute_model == 1)
        {
            ui->pBt_next->hide();
            ui->pBt_ignore->show();
        }
        if(error == "没有成功上传")
        {
            PutIn_info(0);
        }

    }
    else if(num == 1)//显示完成并修改数据库
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::green);
        ui->label_RoleStatus->setPalette(pe);

        if(execute_V->execute_model == 1)
        {
            PutIn_info(1);
            operateNext();

        }



    }
    else if(num == 2)
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::yellow);
        ui->label_RoleStatus->setPalette(pe);

    }
    else if(num == 3)
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::green);
        ui->label_RoleStatus->setPalette(pe);
    }

    ui->label_RoleStatus->setText(error);
/****************************************/



}

void Execut_window::PutIn_info(int order)//入柜信息 写入和更新 //0：失败 1：成功 2:未放置
{
    if(order == 0)
    {
        changeAgentiaStatus(2,0);//上传失败
        savePostFalseInfo();
    }
    else if(order == 1)
    {
        changeAgentiaStatus(1,0);//上传成功
    }
    else if(order == 2)
    {
        changeAgentiaStatus(3,0);//未放置
    }

}

void Execut_window::savePostFalseInfo()//保存上传失败的试剂
{
    int getC_agentiaId;
    int getC_positionId;
    QSqlQuery query;
    if(execute_V->execute_model == 1)
    {
        query.exec(QString("select * from %1").arg(execute_V->T_executeTable));
        query.seek(execute_V->currentAcount);
        getC_agentiaId = query.value(10).toInt();//试剂ID
        getC_positionId = execute_V->positionId;//位置ID
    }
    else if(execute_V->execute_model ==2 )
    {
        query.exec(QString("select * from %1").arg(execute_V->T_executeTable));
        query.seek(execute_V->currentAcount);
        getC_agentiaId = query.value(11).toInt();//试剂ID
        getC_positionId = query.value(12).toInt();//位置ID
    }

    query.exec(QString("select * from T_UserInfo"));
    query.seek(0);
    int getC_userId = query.value(0).toInt();//获取用户ID

    query.exec(QString("select * from T_WaitPostInfo"));
    query.last();
    int getC_all = query.at();//获取数据表格row

    query.prepare("insert into T_WaitPostInfo (id,userId,agentiaId,\
                  positionId,dose,judgeAttitude) values (?,?,?,?,?,?)");
    query.addBindValue(getC_all+1);
    query.addBindValue(getC_userId);
    query.addBindValue(getC_agentiaId);
    query.addBindValue(getC_positionId);
    query.addBindValue("0");
    query.addBindValue("取");
    query.exec();

}

void Execut_window::operateNext()//执行下一步操作
{
    execute_V->currentAcount++;

    if(execute_V->execute_model == 2)
    {
        execute_V->orderPosition++;
    }
    pBt_operate(0);
}

void Execut_window::NetworkError()//网络连接错误
{
    closePage();

    QMessageBox qMbox;
    qMbox.setText(QString("对不起，网络错误请检查网络连接"));
    qMbox.exec();

    if(execute_V->execute_model == 2)
    {
        int getC_agentiaId;
        int getC_positionId;
        QString getC_dose;
        QString getC_status;
        QSqlQuery query;


        query.exec(QString("select * from T_UserInfo"));
        query.seek(0);
        int getC_userId = query.value(0).toInt();//获取用户ID

        query.exec(QString("select * from T_WaitPostInfo"));
        query.last();
        int getC_all = query.at();//获取数据表格row

        query.exec(QString("select * from %1").arg(execute_V->T_executeTable));
        query.last();
        int allLong = query.at();

        for(int i = 0; i <= allLong ; i++)
        {
            query.seek(i);
            getC_status = query.value(13).toString();//状态
            if(getC_status == "正确操作")
            {
                getC_agentiaId = query.value(11).toInt();//试剂ID
                getC_positionId = query.value(12).toInt();//位置ID
                getC_dose       = query.value(4).toString();//dose

                query.prepare("insert into T_WaitPostInfo (id,userId,agentiaId,\
                              positionId,dose,judgeAttitude) values (?,?,?,?,?,?)");
                getC_all++;

                query.addBindValue(getC_all);
                query.addBindValue(getC_userId);
                query.addBindValue(getC_agentiaId);
                query.addBindValue(getC_positionId);
                query.addBindValue("0");
                query.addBindValue("还");
                query.exec();
            }
        }
    }
}

void Execut_window::closePage()
{
    this->close();
    Show_Info->show();
    if(execute_V->execute_model == 2)
    {
        Show_Info->showInfo(1);
    }
    else if(execute_V->execute_model == 1)
    {
        Show_Info->showInfo(0);
    }

    emit upSheet_From_Execute();

}

/*****************************************/



