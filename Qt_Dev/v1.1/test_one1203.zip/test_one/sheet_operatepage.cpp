#include "sheet_operatepage.h"
#include "ui_sheet_operatepage.h"
#include <QDebug>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QMessageBox>

Sheet_OperatePage::Sheet_OperatePage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Sheet_OperatePage)
{
    ui->setupUi(this);
 /*   setWindowTitle(QString("操作界面"));//标题
    setWindowFlags(windowFlags()&~(Qt::WindowMinimizeButtonHint|Qt::WindowMaximizeButtonHint|Qt::WindowCloseButtonHint));
    //最大化等按钮无效化*/
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏

    T_model_execute = new QSqlTableModel;

    T_tableexecute = new T_table;

    http_GAndP_sheetOperate = new http_GAndP;

    connect(http_GAndP_sheetOperate,SIGNAL(sendInfo_To_sheetPage(int)),this,SLOT(receivers_From_http(int)));//接收来自post讯号
}

Sheet_OperatePage::~Sheet_OperatePage()
{
    delete ui;
}

/********************键盘区**************************/

void Sheet_OperatePage::on_pBt_return_clicked()
{
    closeOperate();
}



void Sheet_OperatePage::on_pBt_OK_clicked()
{
    if((sheet_status == 1)||(sheet_status ==3))
    {

        if(sheet_status == 3)
        {
            closeOperate();
        }else{
             sheet_status = 0;
             pBtStatus(2);//查询指令
        }

    }

}

/*******************************************************/

void Sheet_OperatePage::sheetTableInit(int num)
{


    if((num == 1)||(num == 0))//方便再次调用
    {
        T_model_execute->setTable(QString("T_AgentiaExecute"));
        T_model_execute->select();

        T_model_execute->setHeaderData(2,Qt::Horizontal,QObject::tr("试剂名"));
        T_model_execute->setHeaderData(4,Qt::Horizontal,QObject::tr("试剂容量"));
        T_model_execute->setHeaderData(5,Qt::Horizontal,QObject::tr("抽屉号"));
        T_model_execute->setHeaderData(6,Qt::Horizontal,QObject::tr("位置"));
        T_model_execute->setHeaderData(11,Qt::Horizontal,QObject::tr("状态"));

        T_model_execute->setEditStrategy(QSqlTableModel::OnManualSubmit);//自动提交

        T_model_execute->sort(5, Qt::AscendingOrder);//升序，根据抽屉号

        ui->tableView_Execute->setModel(T_model_execute);//关联窗口

        ui->tableView_Execute->setColumnHidden(0,true);//隐藏
        ui->tableView_Execute->setColumnHidden(1,true);
        ui->tableView_Execute->setColumnHidden(3,true);
        ui->tableView_Execute->setColumnHidden(7,true);
        ui->tableView_Execute->setColumnHidden(8,true);
        ui->tableView_Execute->setColumnHidden(9,true);
        ui->tableView_Execute->setColumnHidden(10,true);

        ui->tableView_Execute->setEditTriggers(QAbstractItemView::NoEditTriggers);//窗口不可编辑
        //ui->tableView_Execute->setColumnWidth(2,10);设定columnwidth

    }

    if(num == 1)
    {
        /*********初始化按钮********/

        sheet_model = 0;
        T_tableexecute->rowid = 0;
        sheet_status = 1;
        getDrawer();
        pBtStatus(1);
        T_tableexecute->a = 1;
        /*********************/
        if(T_model_execute->rowCount() == 0)
        {
            closeOperate();
        }
    }

}


void Sheet_OperatePage::changeInfo(int just,int i)//更改试剂信息 1: 上传成功 2：上传失败 3：未摆放
{
    QSqlQuery query;
    QString error;
    if(just == 1)
    {
        error = "上传成功";

    }else if(just == 2)
    {
        error = "上传失败";
    }else if(just == 3)
    {
        error = "未操作";
    }


        query.exec(QString("update T_AgentiaExecute set judgeAttitude='%1' where rowid=%2").arg(error).arg(i+1));


//    T_model_execute->setData(T_model_execute->index(i,11),QString("%1").arg(error));

//    T_model_execute->submitAll();

}

void Sheet_OperatePage::savePostFalse(QString name, int i)//保存上传失败的指令
{
    if(modelOperate == 1)
    {
        QSqlQuery query;
        query.exec(QString("select * from %1").arg(name));
        query.seek(i);
        int getC_agentiaId = query.value(9).toInt();//试剂ID
        int getC_positionId = query.value(10).toInt();//位置ID

        query.exec(QString("select * from T_UserInfo"));
        query.seek(0);
        int getC_userId = query.value(0).toInt();//获取用户ID

        query.exec(QString("select * from T_WaitPostInfo"));
        query.last();
        int getC_all = query.at();//获取数据表格row

        query.prepare("insert into T_WaitPostInfo (id,userId,agentiaId,\
                      positionId,dose,judgeAttitude) values (?,?,?,?,?,?)");
        query.addBindValue(getC_all+1);
        query.addBindValue(getC_userId);
        query.addBindValue(getC_agentiaId);
        query.addBindValue(getC_positionId);
        query.addBindValue("0");
        query.addBindValue("取");
        query.exec();
    }



}


void Sheet_OperatePage::getDrawer()
{

    if(getRead(1))//get drawer count and drawerNo
    {
        QMessageBox qMbox;
        qMbox.setText(QString("数据解析错误"));
        qMbox.exec();
    }

    showNeedData(1,0);


}

void Sheet_OperatePage::updateLabel(int i)//show current drawer
{
    ui->label_allCount->setText(QString("%1").arg(sheet_drawer[0]));
    ui->label_current->setText(QString("%1").arg(sheet_drawer[i]));
}

int Sheet_OperatePage::getRead(char order)//读写 1:得 抽屉号和数量 2:得 试剂位置和总数
                                            //3:得 post信息
{


    if(modelOperate == 1)//get
    {
        if(order == 1)//get draer number
        {

            int rowAll = T_model_execute->rowCount();

            int E_drawer;
            int E_drawer_previous = 0;
            int drawerAll = 0;

            for(int i = 0 ; i < rowAll; i++)
            {
                E_drawer = T_model_execute->data(T_model_execute->index(i,5)).toInt();

                if(E_drawer_previous != E_drawer)
                {
                    drawerAll++;
                    sheet_drawer[0] = drawerAll;
                    sheet_drawer[drawerAll] = E_drawer;
                    E_drawer_previous = E_drawer;
                }

            }

        }
        if(order == 2)//get position info
        {
            sheet_position[0] = T_model_execute->rowCount();
            qDebug()<<sheet_position[0]<<"**********";
            for( int i = 0 ; i < sheet_position[0] ;i++)
            {
                sheet_position[i+1] = T_model_execute->data(T_model_execute->index(i,6)).toInt();
                qDebug()<<sheet_position[i+1];
            }

        }

    }



    return 0;
}

void Sheet_OperatePage::getWriter(int i,int model)//model 0:已摆放 1：未摆放 2：误取 3：误放
{
    QString error;
    if(model == 0){
            error = "已摆放";

    }else if(model == 1){

            error = "未摆放";

    }else if(model == 2){

            error = "误取";

    }else if(model == 3){

            error = "误放";

    }

//  qDebug()<<T_model_execute->data(T_model_execute->index(i,11)).toString();

    T_model_execute->setData(T_model_execute->index(i,11),error);

//  qDebug()<<T_model_execute->data(T_model_execute->index(i,11)).toString();
    T_model_execute->submitAll();

}

void Sheet_OperatePage::showNeedData(int i, char order)//0:show current drawer agentia
                                                      // 1:show all drawer agentia
{
    if(order == 0)
    {
        T_model_execute->setFilter(QString("drawerNo like %1").arg(i));//筛选结果
        T_model_execute->sort(6, Qt::AscendingOrder);

        updateLabel(i);

    }
    if(order == 1)
    {
        sheetTableInit(0);//只初始化表格

        updateLabel(0);
    }


}

void Sheet_OperatePage::sendOrder_to_STM(int status,int drawer)//status 0:success 1:resend 2：query
{

    if((status == 0)||(status == 1))
    {
        getRead(2);//获得试剂位置信息
        if(status == 0)//正常
        {

            /**********指令下发*****************/
             for(int i = 1 ; i <= sheet_position[0]; i++)
             {
                 qDebug()<<QString("我是 %1 号抽屉").arg(drawer);
                 qDebug()<<QString("我是 %1 位置的试剂").arg(sheet_position[i]);
             }
            /*************************/


        }
        else if(status == 1)//重发
        {

            for(int i = 1 ; i <= sheet_position[0]; i++)
            {
                qDebug()<<QString("我是重新发的 %1 位置的试剂").arg(sheet_position[i]);
            }
        }


    }

    if(status == 2)//2:查询
    {

       /**************查询指令******************/

        /**************************************/

        if(T_tableexecute->a == 0)//初始化为1
        {
            QMessageBox qMbox;
            qMbox.setText(QString("误取,更正错误"));
            qMbox.exec();

            sendOrder_to_STM(1,sheet_drawer[sheet_model]);

       }
       else
       {
            qDebug()<<sheet_position[0]<<"  sendorder_to_STM";
            for(int i = 0 ; i < sheet_position[0]; i++)
            {
                getWriter(i,0);
            }
            pBtStatus(1);
       }

    }


}

void Sheet_OperatePage::pBtStatus(int status)//正常发送 1:调用下发指令 2：调用查询指令
{

    if(status == 1)
    {

        if(sheet_model < sheet_drawer[0])
        {
            sheet_model++;

            showNeedData(sheet_drawer[sheet_model],0);//show current drawer agentia info


            /*******指令下发*********************/

            sendOrder_to_STM(0,sheet_drawer[sheet_model]);

            /*******************************/

            ui->pBt_OK->setText(QString("抽屉 %1 完成").arg(sheet_drawer[sheet_model]));
        }
        else if(sheet_model >= sheet_drawer[0])
             {


//                if(sheet_model == sheet_drawer[0]+1)
//                {

        //            qDebug()<<sheet_model<<"   111"<<sheet_drawer[0];
//                }

                showNeedData(1,1);
                ui->pBt_OK->setText(QString("点击退出"));


                sendHttp();

            }else{
                sheet_model++;
            }

    }


    if(status == 2)
    {
        /*******************/
        sendOrder_to_STM(2,0);
        /********************/
        sheet_status = 1;
    }
}

void Sheet_OperatePage::closeOperate()
{
    emit closePrevious();
    this->close();

}

void Sheet_OperatePage::sendHttp()
{
    if(modelOperate == 1)
    {
        int rowAll = T_model_execute->rowCount();
        ui->pBt_OK->setEnabled(false);
        ui->pBt_return->setEnabled(false);

        if(T_tableexecute->rowid < rowAll)
        {

           http_GAndP_sheetOperate->jsonForSend(7,"T_AgentiaExecute",T_tableexecute->rowid);
        }
        else
        {
            ui->pBt_OK->setEnabled(true);
            ui->pBt_return->setEnabled(true);
        }


    }
}

void Sheet_OperatePage::receivers_From_http(int status)//0:ok 1:post失败 2：未摆放
{
    if(modelOperate == 1)
    {
        if(status == 0)//OK
        {
            changeInfo(1,T_tableexecute->rowid);

        }
        if(status == 1)//post 失败
        {
            savePostFalse("T_AgentiaExecute",T_tableexecute->rowid);
            changeInfo(2,T_tableexecute->rowid);

        }
        if(status == 2)//未摆放
        {
            changeInfo(3,T_tableexecute->rowid);
        }
        T_tableexecute->rowid++;
        sendHttp();
        sheetTableInit(0);
        sheet_status = 3;
    }
}

void Sheet_OperatePage::delSheetInfo(int status,QString name ,int i)//0: 全部清除 1：选定删除内容
{
    QSqlQuery query;

    if(modelOperate == 1)
    {
        if(status == 0)
        {
            query.exec(QString("DELETE * from %1").arg(name));
        }
        if(status == 1)
        {
            query.exec(QString("delete from %1 where rowid = %2").arg(name).arg(i));
        }
    }


}


