#ifndef MYQHEADERVIEW_H
#define MYQHEADERVIEW_H

#define CHECKBOX_COLUMN_0 0
#define CHECKBOX_COLUMN_1 1
#define CHECKBOX_COLUMN_2 2

#include <QHeaderView>


class MyQHeaderView : public QHeaderView
{
    Q_OBJECT
public:
    explicit MyQHeaderView(Qt::Orientation orientation, QWidget *parent = 0);



signals:
      void stateUP(int state);
//    void clickRow(bool bBoxState);
//    void stateChanged(int state);
public slots:
    void SetHeaderBox(int state);
  //  void onStateChanged(int state);

protected:
    void paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const;
    void mousePressEvent(QMouseEvent *e);
  //  void mouseReleaseEvent(QMouseEvent *e);
   // bool event(QEvent *e);
  //  void paintEvent(QPaintEvent* event);


    struct{

        bool isOn;

    }test_1;






};

#endif // MYQHEADERVIEW_H
