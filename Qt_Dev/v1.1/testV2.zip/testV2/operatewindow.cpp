#include "operatewindow.h"
#include "ui_operatewindow.h"
#include <QSqlRelationalDelegate>
#include "myqheaderview.h"
#include "checkboxdelegate.h"

OperateWindow::OperateWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OperateWindow)
{
    ui->setupUi(this);
    T_table = &T_TABLE;
    query                = new QSqlQuery;
    T_model_Other_Execut = new QSqlTableModel;
    T_model_Other_Search = new QSqlTableModel;
    T_model_PutIn        = new QSqlRelationalTableModel;
    Operate_execut_Page  = new Execut_window;


}

OperateWindow::~OperateWindow()
{
    delete ui;
}

void OperateWindow::on_Bt_backBefore_clicked()
{
    emit OperateWindow_To_MainUI();
}

void OperateWindow::on_Bt_searchInfo_clicked()
{

}

void OperateWindow::on_Bt_execute_clicked()
{
    Operate_execut_Page->show();
    Operate_execut_Page->executInit(1);
}

void OperateWindow::on_Bt_delete_clicked()
{

}

void OperateWindow::on_Bt_add_clicked()
{

}



/**************************************************/
void OperateWindow::ModelSelect(int num)
{
    switch (num) {
    case 1 :{
        T_table->T_execut_RelationTable="T_Task_PutIn";
        T_table->T_search_RelationTable="T_AgentiaTypeList";
        T_table->dialog_model=1;
        ui->label_title->setText("入柜");
        break;
    }
    default:
        break;
    }


    tableInit();
}


void OperateWindow::tableInit()
{
    MyQHeaderView *pHeader = new MyQHeaderView(Qt::Horizontal,this);
    CheckBoxDelegate *checkBoxDelegate = new CheckBoxDelegate(this);

    T_model_Other_Search->setTable(QString("%1").arg(T_table->T_search_RelationTable));
    T_model_Other_Search->select();
    T_model_Other_Search->setHeaderData(0,Qt::Horizontal,QObject::tr("勾选"));
    T_model_Other_Search->setHeaderData(1,Qt::Horizontal,QObject::tr("添加"));
    T_model_Other_Search->setHeaderData(2,Qt::Horizontal,QObject::tr("试剂名"));
    T_model_Other_Search->setHeaderData(3,Qt::Horizontal,QObject::tr("试剂类别"));
    T_model_Other_Search->setHeaderData(4,Qt::Horizontal,QObject::tr("额定容量"));
    T_model_Other_Search->setHeaderData(5,Qt::Horizontal,QObject::tr("实际容量"));
    T_model_Other_Search->setHeaderData(6,Qt::Horizontal,QObject::tr("制造商"));
    T_model_Other_Search->setHeaderData(7,Qt::Horizontal,QObject::tr("状态"));
    T_model_Other_Search->setHeaderData(8,Qt::Horizontal,QObject::tr("试剂ID"));

    ui->tableView_showSearchInfo->setModel(T_model_Other_Search);//关联窗口


    ui->tableView_showSearchInfo->setHorizontalHeader(pHeader);
    ui->tableView_showSearchInfo->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    ui->tableView_showSearchInfo->setItemDelegateForColumn(0,checkBoxDelegate);
    ui->tableView_showSearchInfo->setEditTriggers(QAbstractItemView::NoEditTriggers);//窗口不可编辑

    if(T_table->dialog_model==1)
    {
        T_model_PutIn->setTable(QString("%1").arg(T_table->T_execut_RelationTable));
        T_model_PutIn->select();
        T_model_PutIn->setRelation(5,QSqlRelation("T_DrawerSizeChoice","drawerSize","drawerSize"));//外键

        T_model_PutIn->setEditStrategy(QSqlTableModel::OnFieldChange);

        T_model_PutIn->setHeaderData(0,Qt::Horizontal,QObject::tr("勾选"));
        T_model_PutIn->setHeaderData(1,Qt::Horizontal,QObject::tr("删除"));
        T_model_PutIn->setHeaderData(2,Qt::Horizontal,QObject::tr("试剂名"));
        T_model_PutIn->setHeaderData(3,Qt::Horizontal,QObject::tr("额定容量"));
        T_model_PutIn->setHeaderData(4,Qt::Horizontal,QObject::tr("实际容量"));
        T_model_PutIn->setHeaderData(5,Qt::Horizontal,QObject::tr("规格"));
        T_model_PutIn->setHeaderData(6,Qt::Horizontal,QObject::tr("入柜日期"));
        T_model_PutIn->setHeaderData(7,Qt::Horizontal,QObject::tr("状态"));
        T_model_PutIn->setHeaderData(8,Qt::Horizontal,QObject::tr("试剂ID"));
        T_model_PutIn->setHeaderData(9,Qt::Horizontal,QObject::tr("任务状态"));



        ui->tableView_showExecuteInfo->setModel(T_model_PutIn);

        ui->tableView_showExecuteInfo->setItemDelegate(new QSqlRelationalDelegate(ui->tableView_showExecuteInfo));//委托显示


    }

//    widgetInit();
}

/*void OperateWindow::widgetInit()
{*/
/*******执行框*********/
   /* if(T_table->dialog_model==1)
    {
        int rowAcount_E = T_model_PutIn->rowCount();

//        QCheckBox *checkBox_E[rowAcount_E];
//        QPushButton *pushBt_E[rowAcount_E];

        for(int i = 0; i < rowAcount_E; ++i)
        {
//            checkBox_E[i] = new QCheckBox(this);
//            checkBox_E[i]->setCheckState(Qt::Unchecked);

            pushBt_E[i] = new QPushButton(this);
            pushBt_E[i]->setText("-");

//            ui->tableView_showExecuteInfo->setIndexWidget(T_model_PutIn->index(i,0),checkBox_E[i]);
            ui->tableView_showExecuteInfo->setIndexWidget(T_model_PutIn->index(i,1),pushBt_E[i]);
        }

    }else{

        int rowAcount_E = T_model_Other_Execut->rowCount();


        for(int i = 0; i < rowAcount_E; ++i)
        {
//            checkBox_E[i] = new QCheckBox(this);
//            checkBox_E[i]->setCheckState(Qt::Unchecked);

            pushBt_E[i] = new QPushButton(this);
            pushBt_E[i]->setText("-");

//            ui->tableView_showExecuteInfo->setIndexWidget(T_model_Other_Execut->index(i,0),checkBox_E[i]);
            ui->tableView_showExecuteInfo->setIndexWidget(T_model_Other_Execut->index(i,1),pushBt_E[i]);
        }
    }

 /****搜索框*****/
   /* int rowAcount_S = T_model_Other_Search->rowCount();//获取总的行数



    for(int i = 0; i < rowAcount_S; ++i)
    {
       // checkBox_S[i] = new QCheckBox(this);
//        checkBox_S[i]->setCheckState(Qt::Unchecked);

        pushBt_S[i] = new QPushButton(this);
        pushBt_S[i]->setText("+");

//        ui->tableView_showSearchInfo->setIndexWidget(T_model_Other_Search->index(i,0),checkBox_S[i]);
        ui->tableView_showSearchInfo->setIndexWidget(T_model_Other_Search->index(i,1),pushBt_S[i]);
    }
}
*/
//bool OperateWindow::eventFilter(QObject *watched, QEvent *event)
//{
//    if(event->type() == QEvent::MouseButtonPress){
//        qDebug()<<"1111111111";
//    }

//    return true;
//}

