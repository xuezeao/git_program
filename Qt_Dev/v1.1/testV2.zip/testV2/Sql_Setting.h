#ifndef SQL_SETTING_H
#define SQL_SETTING_H

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QFile>
#include <QSqlError>


static bool createConnection()
{
//   QSqlDatabase::removeDatabase("QSQLITE");//删除数据库
     QFile::remove("SmartCabinet.db");//删除数据库文件

       QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
       db.setDatabaseName("SmartCabinet.db");
       if(!db.open()) return false;
       QSqlQuery query;

       query.exec(QString("create table T_CabinetInfo ([cabinetName] varchar,[groupId] int,[groupName] varchar,[drawerAmount] int)"));
       //长期存放柜子信息

       query.exec(QString("create table T_DrawerList ([drawerNo] int,[drawerName] varchar,[drawerSize] varchar,[positionAmount] int,[attribute] int)"));
       //长期抽屉信息

       query.exec(QString("create table T_AgentiaInBox (id int primary key,[checkBox] varchar,[agentiaName] varchar,[bottleCapacity] varchar,[dose] varchar,[drawerNo] int,[positionNo] int,[expireDate] varchar,[attribute] int,[agentiaId] int,[positionId] int)"));
       //在柜信息(点验)

       query.exec(QString("create table T_AgentiaTypeList (id int primary key,[checkBox] varchar,[agentiaName] varchar,[abbreviation] varchar,[chemicalFormula] varchar,[specification] varchar,[factory] varchar,[attribute] int,[agentiaTypeId] int)"));
       //试剂类型
       query.exec(QString("insert into T_AgentiaTypeList values (1,'1','酒精','酒精','500ml','400ml','1',1,1)"));
       query.exec(QString("insert into T_AgentiaTypeList values (2,'1','酒精','酒精','500ml','400ml','1',1,1)"));
       query.exec(QString("insert into T_AgentiaTypeList values (3,'1','酒精','酒精','500ml','400ml','1',1,1)"));
       query.exec(QString("insert into T_AgentiaTypeList values (4,'1','酒精','酒精','500ml','400ml','1',1,1)"));
       query.exec(QString("insert into T_AgentiaTypeList values (5,'1','酒123精','酒23精','53123ml','12ml','1',1,1)"));
       query.exec(QString("insert into T_AgentiaTypeList values (6,'1','酒23精','酒312精','5230ml','3ml','1',1,1)"));



       query.exec(QString("create table T_AgentiaSearchInfo (id int primary key,[checkBox] varchar,[agentiaName] varchar,[bottleCapacity] varchar,[dose] varchar,[drawerNo] int,[positionNo] int,[expireDate] varchar,[currentUserName] varchar,[agentiaStatus] varchar,[attribute] varchar,[applicant] varchar,[applyStatus] int,[agentiaId] int,[positionId] int)"));
       //搜索信息


       query.exec(QString("create table T_Task_PutIn (id int primary key,[checkBox] varchar,[agentiaName] varchar,[bottleCapacity] varchar,[dose] varchar,[drawerSize] varchar,[expireDate] varchar,[attribute] int,[agentiaTypeId] int,[roleStatus] int)"));
       //入柜
       query.exec(QString("insert into T_Task_PutIn values (1,'1','酒精','500ml','400ml','10*10*20','2017.1.1',1,1,0)"));
       query.exec(QString("insert into T_Task_PutIn values (2,'1','酒精','500ml','400ml','10*10*20','2017.1.1',1,1,0)"));
       query.exec(QString("insert into T_Task_PutIn values (3,'1','酒精','500ml','400ml','10*10*20','2017.1.1',1,1,0)"));




//       query.exec(QString("create table T_Task_Operate (id int primary key,[checkBox] varchar,agentiaId int,[agentiaName] varchar,[bottleCapacity] varchar,[dose] varchar,[expiryDate] varchar,[drawerNo] int,[drawerName] varchar,[drawerSize] varchar,[positionId] varchar,[positionNo] varchar,[positionName] varchar,[attribute] int)"));
//       //临时存储信息，取，报废，替换，点验，申请任务,待归还信息，入柜的执行界面1
//       query.exec(QString("insert into T_Task_Operate values ('1','1',1,'酒精','500ml','400ml','2017.1.1',1,'Draw-1','10*10*20','1','1','1', 1)"));

//        query.exec(QString("create table T_Task_return (id int ,[checkBox] varchar,[agentiaId] varchar primary key,[bottleCapacity] varchar,[dose] varchar,[expiryDate] varchar,[drawerNo] varchar,[drawerName] varchar,[positionNo] varchar,[positionName] varchar,[positionId] varchar,[attribute] varchar)"));
//       //临时存储归还信息
//       query.exec(QString("create table T_Task_return_opetation (id int ,[checkBox] varchar ,[agentiaId] varchar primary key,[bottleCapacity] varchar,[dose] varchar,[expiryDate] varchar,[drawerNo] varchar,[drawerName] varchar,[positionNo] varchar,[positionName] varchar,[positionId] varchar,[attribute] varchar)"));
//       //临时存储确定归还信息
//       query.exec(QString("create table T_CabinetStatus (id int primary key,[checkBox] varchar,[cabinetName] varchar,[cabinetStatue] varchar,[temperature] varchar,[humidity] varchar)"));
//       //柜子信息更新表1
//       query.exec(QString("create table T_PositionDisable (id int primary key,[checkBox] varchar,[drawerNo] varchar,[drawerName] varchar,[drawerSize] varchar,[positionAmount] varchar,[attribute] varchar,[drawerStatus] varchar)"));
//       //修改柜子信息1
//       query.exec(QString("create table T_WaringLog (id int primary key,[checkBox] varchar,[cabinetNo] varchar,[drawerNo] varchar,[positionNo] varchar,[taskId] varchar,[message] varchar)"));
//       //报警信息1
//       query.exec(QString("create table T_PositionAllocate ([positionNo] varchar,[positionName] varchar,[positionId] varchar,[drawerNo] varchar,[drawerName] varchar)"));
//       //存储临时位置分配信息1
//       query.exec(QString("create table T_DrawerSize ([id] int)"));
//       //存储试剂规格信息1


//       query.exec(QString("insert into BackReagent values (4,'酒精','3-2',500,'管制','大','2016.10.12','2016.8.9','未放')"));

       query.exec(QString("create table T_DrawerSizeChoice (drawerSize varchar)"));//仅用于入柜drawerSize

       query.exec(QString("insert into T_DrawerSizeChoice values ('10*10*20')"));
       query.exec(QString("insert into T_DrawerSizeChoice values ('10*20*10')"));
       query.exec(QString("insert into T_DrawerSizeChoice values ('20*10*10')"));

       return true;

}
#endif // SQL_SETTING_H
