#include "execut_window.h"
#include "ui_execut_window.h"
#include <QSqlQuery>
#include <QPalette>

Execut_window::Execut_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Execut_window)
{
    ui->setupUi(this);

    Execut_http_GAndP = new http_GAndP;

    setWindowTitle(QString("执行中"));//标题

    execut_V = &EXECUT;
    execut_V->acountRow=1;//令表格指向第一行

    connect(Execut_http_GAndP,SIGNAL(sendInfo_To_Execut(int,int)),this,SLOT(executShow(int,int)));
    connect(Execut_http_GAndP,SIGNAL(sendError_To_Execut(int,QString)),this,SLOT(executError(int,QString)));

}
/****************************串口通讯通过这个就行了****************************************/
bool Execut_window::executShow(int drawerNo,int positionNo)//当http解析完系统反馈true才能继续执行
{

    qDebug()<<drawerNo<<"***OK***"<<positionNo;

    QSqlQuery query;
    QString show_Name;
    QString show_Volume;
    QString show_position;

    query.exec(QString("select * from '%1' where rowid = '%2'")//从id=rownum中选中所有属性 '*' /也可指定 'name'
               .arg(execut_V->T_executTable).arg(execut_V->acountRow));
    query.next();

    if(execut_V->execut_model == 1)//入柜
    {
        show_Name = query.value(2).toString();
        show_Volume = query.value(4).toString();
        show_position = QString("抽屉：%1，位置：%2").arg(drawerNo).arg(positionNo);

        qDebug()<<show_position;

        ui->lineEdit_Name->setText(show_Name);
        ui->lineEdit_Volume->setText(show_Volume);
        ui->lineEdit_Position->setText(show_position);

        ui->label_RoleStatus->setText("请放置药剂");
    }



    return true;
}


/*************************按键区*************************************/



Execut_window::~Execut_window()
{
    delete ui;
}

void Execut_window::on_pBt_cancal_clicked()
{
    this->close();
}

void Execut_window::on_pBt_jump_clicked()
{

    execut_V->acountRow +=1;
    executOperate();

}

void Execut_window::on_pBt_next_clicked()
{
    QSqlQuery query;
    query.exec(QString("UPDATE '%1' SET roleStatus=1 WHERE rowid = '%2'")
                 .arg(execut_V->T_executTable).arg(execut_V->acountRow));//改变试剂状态


    execut_V->acountRow +=1;
    executOperate();

}

/********************自定函数区************************/

void Execut_window::executInit(int num)
{
    switch (num) {
    case 1:{
        ui->label_title->setText("入柜");
        execut_V->T_executTable="T_Task_PutIn";
        execut_V->execut_model=1;
        break;
    }
    default:
        break;
    }

    executOperate();
}

void Execut_window::executOperate()//生成json信息这个是在http文件
{
    if(execut_V->execut_model == 1)
    {
        Execut_http_GAndP->jsonForSend(5,execut_V->T_executTable,execut_V->acountRow);//调用生成json信息
    }

    ui->pBt_next->setEnabled(false);//每次任务没有完成前将下一步按钮失效

}














void Execut_window::executError(int num, QString error)//输出任务状态
{
    if(num == 0)
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::red);
        ui->label_RoleStatus->setPalette(pe);
    }
    if(num == 1)
    {
        QPalette pe;
        pe.setColor(QPalette::WindowText,Qt::green);
        ui->label_RoleStatus->setPalette(pe);

        /*****任务OK*****/
        ui->pBt_next->setEnabled(true);//设置按钮可用
    }

    ui->label_RoleStatus->setText(error);


}

void Execut_window::on_judge_pushButton_clicked()
{

    /****************串口通讯区*************************/



    /******************如果OK执行*************************/
    if()
    {
        Execut_http_GAndP->jsonForSend(6,execut_V->T_executTable,execut_V->acountRow);//调用生成json信息
        executError(0,"正确操作");
    }else
    {
        executError(1,"错误操作");
    }
}
