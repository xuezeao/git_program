#include "myqheaderview.h"

#include <QPainter>
#include <QRect>
#include <QStyleOptionButton>
#include <Qstyle>
#include <QCheckBox>
#include <QSize>
#include <QMouseEvent>
#include <QDebug>

MyQHeaderView::MyQHeaderView(Qt::Orientation orientation,QWidget *parent) :
    QHeaderView(orientation,parent)
{
    setHighlightSections(false);
    setMouseTracking(true);
    setSectionsClickable(true);//响应鼠标


    test_1.isOn = false;

}

void MyQHeaderView::paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const
{
    painter->save();
    QHeaderView::paintSection(painter, rect, logicalIndex);
    painter->restore();
    if( (logicalIndex == CHECKBOX_COLUMN_1))
    {
        QStyleOptionButton option;
        option.initFrom(this);

        if (test_1.isOn)
        {
            option.state = QStyle::State_On;

        }else{

            option.state = QStyle::State_Off;

        }

        QCheckBox   checkBox;
        option.iconSize = QSize(30,30);
        option.rect = rect;
        style()->drawPrimitive(QStyle::PE_IndicatorCheckBox, &option, painter, &checkBox);

    }
}
void MyQHeaderView::mousePressEvent(QMouseEvent *event)
{
    if (visualIndexAt(event->pos().x()) == CHECKBOX_COLUMN_1)
    {
        if (test_1.isOn)
        {
            test_1.isOn = false;
            emit stateUP(-1);
        }
        else
        {
            test_1.isOn = true;
            emit stateUP(1);
        }
        update();
    }

    QHeaderView::mousePressEvent(event);
}

void MyQHeaderView::SetHeaderBox(int state)
{
    if(state ==1)
    {
        test_1.isOn = false;
        update();
    }
}


/*
void MyQHeaderView::onStateChanged(int state)
{
    if( state == Qt::PartiallyChecked)
    {
      //  m_status.m_bTristate = true;
        m_status.m_bNoChange = true;
    }else{

        m_status.m_bNoChange = false;
    }

    m_status.m_bChecked = (state != Qt::Unchecked);
    update();
}


void MyQHeaderView::paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const
{
    painter->save();
    QHeaderView::paintSection(painter, rect, logicalIndex);
    painter->restore();
    if( (logicalIndex == CHECKBOX_COLUMN_1))
    {
        QStyleOptionButton option;
        option.initFrom(this);

        if(m_status.m_bChecked)
            option.state |= QStyle::State_Sunken;

        if( m_status.m_bNoChange)//m_status.m_bTristate &&
            option.state |= QStyle::State_NoChange;
        else
            option.state |= m_status.m_bChecked ? QStyle::State_On : QStyle::State_Off;

       if(testAttribute(Qt::WA_Hover) && underMouse()){
            if(m_status.m_bMoving)
                option.state |= QStyle::State_MouseOver;
            else
                option.state &= ~QStyle::State_MouseOver;

    }




        QCheckBox   checkBox;
        option.iconSize = QSize(30,30);
        option.rect = rect;
        style()->drawPrimitive(QStyle::PE_IndicatorCheckBox, &option, painter, &checkBox);



   }


}

void MyQHeaderView::mousePressEvent(QMouseEvent *e)
{
    int nColumn = logicalIndexAt(e->pos());

    if(e->buttons() && Qt::LeftButton)
    {
        if(nColumn == CHECKBOX_COLUMN_1)
        m_status.m_bPressed = true;
        m_status.m_bNoChange= false;


    }
    else{
        QHeaderView::mousePressEvent(e);

    }
    update();

}

void MyQHeaderView::mouseReleaseEvent(QMouseEvent *e)
{
    if(m_status.m_bPressed)
    {
            if( m_status.m_bNoChange)//m_status.m_bTristate &&
            {
                m_status.m_bChecked = true;

            }else{

                m_status.m_bChecked = !m_status.m_bChecked;
            }

            update();

            Qt::CheckState state = m_status.m_bChecked ? Qt::Checked : Qt::Unchecked;

            emit stateChanged(state);
            onStateChanged(state);
    }else{
        QHeaderView::mouseReleaseEvent(e);
    }

    m_status.m_bPressed = false;
}

bool MyQHeaderView::event(QEvent *e)
{
    if(e->type() == QEvent::Enter || e->type() == QEvent::Leave )
    {
        QMouseEvent *pEvent = static_cast<QMouseEvent *>(e);
        int nColumn = logicalIndexAt(pEvent->x());
        if(nColumn == CHECKBOX_COLUMN_1)
        {
            m_status.m_bMoving = (e->type() == QEvent::Enter);

            update();
            return true;
       }
    }

    return QHeaderView::event(e);

}


*/
