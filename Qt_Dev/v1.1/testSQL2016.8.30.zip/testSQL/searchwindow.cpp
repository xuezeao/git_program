#include "searchwindow.h"
#include "ui_searchwindow.h"
#include <QSqlRecord>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QMessageBox>
#include <QMouseEvent>
#include <QSqlQueryModel>
#include <QComboBox>
#include <QPushButton>
#include <QMouseEvent>
#include <QHeaderView>

QString operateModel;//选择框
QString searchModel;//待选择框
QString needModel;//模式选择--执行框
searchWindow::searchWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::searchWindow)
{
    ui->setupUi(this);
    createArray();
    qDebug()<<NeedSheet[10];
    qDebug()<<searchSheet[10];
    AllPage_SEA = new popupPage;
    teapage = new additionNews(this);
    model = new QSqlTableModel(this);
    delFunction = new delNews(this);
    ui->widget_SEARCH->setObjectName("widget_SEARCH");
    ui->widget_SEARCH->setStyleSheet(  "#widget_SEARCH{"
                                     "font-size:16px;"
                                     "border-image:url(:/image/background2.bmp);"
                                     "}");
// this->showFullScreen();//主屏幕最大化

//    addCheckBox(model,1);

//    connect(teapage,SIGNAL(send()),this,SLOT(testslot()));

    connect(AllPage_SEA,SIGNAL(backGPage()),this,SLOT(operatePage_To_SEA()));
    connect(AllPage_SEA,SIGNAL(backReturn()),this,SLOT(operatePage_To_SEA()));
//    QString ad="ad";
//    ui->label_title->setText(QString("%1").arg(ad));//



}
void searchWindow::searchSelect(int num)
{
    switch (num) {
    case 2 :searchModel="T_Task";operateModel="T_Task_Operate";
        needModel="取试剂";
        qDebug()<<needModel;
        dialog_model=2;
        break;

    case 3 :searchModel="T_Task_return";
            operateModel="T_Task_return_opetation";
            needModel="归还试剂";

            dialog_model=3;
            qDebug()<<needModel;


            break;
    default:
        break;
    }


     ui->label_title->setText(QString("%1").arg(needModel));
     mainUI();
}
void searchWindow::waitPostInfo(char a)
{
    QElapsedTimer t;//主程序等待
    t.start();
     while(t.elapsed() < a)
     {
         QCoreApplication::processEvents();
     }
}
//void searchWindow::testslot()
//{
//    qDebug()<<"sended";
//}

searchWindow::~searchWindow()
{
    delete ui;
}

void searchWindow::addCheckBox(QSqlTableModel *modelName,int modelAB)
{
    int adf=modelAB;
    choiceModel = modelName;
    int nRow = choiceModel->rowCount();
    for(int i=0;i<nRow;++i)
    {
//        QCheckBox *((searchSheet[i]))= new QCheckBox(this);
//        ui->tableView_showSearch->setIndexWidget(choiceModel->index(i,0),searchSheet[i]);
    }
}
void searchWindow::createArray()
{
    for(int i=0;i<255;++i)
    {
        QString oneSheet=(QString("a%1").arg(i));
        QString twoSheet=(QString("b%1").arg(i));
        searchSheet[i]=oneSheet;
        NeedSheet[i]=twoSheet;

    }
}

void searchWindow::on_pushButton_searchNews_clicked()
{
    QString reagentName = ui->lineEdit_search->text();//获取搜索框内容
    qDebug()<<reagentName;
    if(reagentName=="")
    {
        model->setTable(QString("%1").arg(searchModel));

    }else

        model->setFilter(QString("agentiaName like '%%1%'").arg(reagentName));//筛选结果
    model->select();//显示
 qDebug()<<QString("agentiaName like '%%1%'").arg(reagentName);
}

void searchWindow::addNewsToApplySheet()//将选定信息添加到执行框
{
     int curRow = ui->tableView_showSearch->currentIndex().row();
     qDebug()<<"*********************"<<curRow;
//     model->setTable(QString("%1").arg(searchModel));
     QSqlRecord record = model->record(curRow);//获取指定行的记录
    qDebug()<<record;
    QSqlQuery query;
    query.exec(QString("insert into %1 select * from %2 where rowid='%3'").arg(operateModel).arg(searchModel).arg(curRow+1));//将A表向b添加选中记录
  //  query.next();   //作用同上面这句函数效果一致
//    QSqlRecord record1 = applyNews->record(1);
//    qDebug()<<"12312312"<<record1;
//    QSqlRecord record21 = applyNews->record(0);
//    qDebug()<<"12312312"<<record21;
    applyNews->setTable(QString("%1").arg(operateModel));

    applyNews->select();
    ui->tableView_showNeedReagent->setModel(applyNews);

   //  int getRowNum = applyNews->rowCount();//获得行数
 //    applyNews->insertRow(getRowNum);
//     applyNews->setData(applyNews->index(getRowNum),record);

}

void searchWindow::delNewsFromApplySheet()
{
//    applyNews->setTable("choiceReagent");

//    applyNews->select();
//    ui->tableView_showNeedReagent->setModel(applyNews);

    //获取选中的行
    int curRow = ui->tableView_showNeedReagent->currentIndex().row();

    //删除该行
    applyNews->removeRow(curRow);
    applyNews->submitAll(); //否则提交，在数据库中删除该行

}

void searchWindow::on_pushButton_delThisNews_clicked()

{
    //获取选中的行
    int curRow = ui->tableView_showNeedReagent->currentIndex().row();

    //删除该行
    applyNews->removeRow(curRow);

//    qDebug()<<"--------------------------"<<curRow;
  //  int ok = QMessageBox::warning(this,tr("删除当前行!"),tr("你确定"
//                                                       "删除当前行吗？"),
//                                  QMessageBox::Yes,QMessageBox::No);
//    if(ok == QMessageBox::No)
//    {
//        applyNews->revertAll(); //如果不删除，则撤销
//    }
//    else
    applyNews->submitAll(); //否则提交，在数据库中删除该行

}
bool searchWindow::eventFilter(QObject * obj, QEvent * event)
{
    QMouseEvent *e = (QMouseEvent *) event;
    int clickX =e->x();
    int clickY =e->y();

//    qDebug()<<clickX;
//    qDebug()<<clickY;
//    qDebug()<<"局部-------------------";


//    int globalX=e->globalX();//获取全局变量
//    int globalY=e->globalY();
//    if(obj == ui->tableView_showSearch)
//    qDebug()<<globalX;
//    qDebug()<<globalY+"全局---------------------";

    if(obj==ui->tableView_showSearch->viewport())
    {
//        qDebug()<<"OK sending";
        if(event->type() == QEvent::MouseButtonPress)
      {
            int rowAllAAcount = model->rowCount();
            int tableAW = ui->tableView_showSearch->columnWidth(0);
            int tableAH = ui->tableView_showSearch->rowHeight(0);
            if(clickX > 0 && clickX < tableAW)
            {
                if(clickY > 0 && clickY < rowAllAAcount*tableAH)
                {
                    qDebug()<<"one OK";
                   addNewsToApplySheet();
                }
            }

       }

    }
    if(obj==ui->tableView_showNeedReagent->viewport())
    {
         if(event->type() == QEvent::MouseButtonPress)
       {
             int rowAllBAcount = applyNews->rowCount();
             int tableBW = ui->tableView_showNeedReagent->columnWidth(0);
             int tableBH = ui->tableView_showNeedReagent->rowHeight(0);
             if(clickX > 0 && clickX < tableBW)
             {
                 if(clickY > 0 && clickY < rowAllBAcount*tableBH)
                 {
                     qDebug()<<"two OK ";
                     delNewsFromApplySheet();

                 }
             }

        }
    }

}


void searchWindow::mainUI()
{

//    model->setTable("placeDurg");

    model->setTable(QString("%1").arg(searchModel));
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->select();
    ui->tableView_showSearch->setModel(model);
    ui->tableView_showSearch->setEditTriggers(QAbstractItemView::NoEditTriggers);//窗口不可编辑
    ui->tableView_showSearch->viewport()->installEventFilter(this);//设置窗口鼠标事件

    ui->tableView_showSearch->horizontalHeader()->setStretchLastSection(true);
    ui-> tableView_showSearch->setItemDelegateForColumn(0, new additionNews);



    applyNews = new QSqlTableModel(this);//关联数据库，设置为自动保存，窗口不可编辑
    applyNews->setTable(QString("%1").arg(operateModel));
    applyNews->setEditStrategy(QSqlTableModel::OnManualSubmit);
    applyNews->select();
//    QComboBox *comBox = new QComboBox();
//    comBox->addItem("F");
//    comBox->addItem("M");
//    ui->tableView_showSearch->setIndexWidget(model->index(0,0),comBox);
    //可实现在表中显示部分按钮
//    QPushButton *pushbutton = new QPushButton();
//    ui->tableView_showSearch->setIndexWidget(model->index(0,0),pushbutton);
//    ui->tableView_showNeedReagent->setModel(applyNews);
    ui->tableView_showNeedReagent->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableView_showNeedReagent->viewport()->installEventFilter(this);
    ui->tableView_showNeedReagent->setItemDelegateForColumn(0,new delNews);

    ui->tableView_showSearch->viewport()->installEventFilter(this);//设置窗口鼠标事件

}


void searchWindow::on_commandLinkButton_clicked()
{
    emit GPageToMainUi();
}

void searchWindow::operatePage_To_SEA()
{
    this->show();
    this->showFullScreen();
    AllPage_SEA->close();
}

void searchWindow::on_pushButton_sureNewsApply_clicked()
{
//    this->close();
    AllPage_SEA->selectModel(dialog_model);
    AllPage_SEA->show();
    AllPage_SEA->showFullScreen();
    AllPage_SEA->acount=1;
}
