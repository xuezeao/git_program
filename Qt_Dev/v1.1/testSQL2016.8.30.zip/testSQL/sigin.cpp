#include "sigin.h"
#include "ui_sigin.h"
#include <QPixmap>
#include <QMessageBox>

sigin::sigin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sigin)
{
    ui->setupUi(this);
    MainUI_page = new MainUI;

//    ui->graphicsView->autoFillBackground();
    //    post_Info="0";
    //    postHttp(1,post_Info);//获取所有信息
    //    ModelOperate=1;
 this->showFullScreen();//主屏幕最大化
    MainUI_page->getHttp();
    MainUI_page->ModelOperate=0;
    ui->widget->setObjectName("widget");
    ui->widget->setStyleSheet("#widget{"
                              "font-size:16px;"
                              "border-image:url(:/image/background2.bmp);"
                              "}");
}

sigin::~sigin()
{
    delete ui;
}

void sigin::on_pushButton_sigin_clicked()
{
    if((ui->lineEdit_acount->text() == tr("admin"))&&(ui->lineEdit_password->text() == tr("123456")))
    {
//        emit open_Option();
        MainUI_page->show();
        MainUI_page->showFullScreen();
        this->close();
        MainUI_page->postHttp(2,QString("%1").arg(0));

    }
    else{
        QMessageBox::warning(this,tr("Waring"),tr("user name or password error!"),QMessageBox::Yes);
         ui->lineEdit_acount->clear();
         ui->lineEdit_password->clear();
         ui->lineEdit_acount->setFocus();
    }
}
