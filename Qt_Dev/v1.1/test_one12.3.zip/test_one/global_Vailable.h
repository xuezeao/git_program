#ifndef GLOBAL_VAILABLE_H
#define GLOBAL_VAILABLE_H

#define CABINETNO "AABBCCDD"        //试剂柜编号

#define ROW_ALLACOUNT 100

#define FALSE 0
#define TRUE  1

void waitOtherThing(int a);//等其他事件 ms


#endif // GLOBAL_VAILABLE_H
