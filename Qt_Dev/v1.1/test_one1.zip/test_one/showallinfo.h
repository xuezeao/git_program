#ifndef SHOWALLINFO_H
#define SHOWALLINFO_H

#include <QWidget>
#include <QSqlTableModel>

namespace Ui {
class ShowAllInfo;
}

class ShowAllInfo : public QWidget
{
    Q_OBJECT

public:
    explicit ShowAllInfo(QWidget *parent = 0);
    ~ShowAllInfo();

    void showInfo(int order);//显示试剂信息 0:入柜 1：还
signals:


private slots:
    void on_pBt_close_clicked();




private:
    Ui::ShowAllInfo *ui;

    QSqlTableModel *T_model_show;

    QString T_name;


};

#endif // SHOWALLINFO_H
