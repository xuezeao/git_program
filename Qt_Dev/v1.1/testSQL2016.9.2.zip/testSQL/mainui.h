#ifndef MAINUI_H
#define MAINUI_H

#define CABINETNO "AABBCCDD"

#include <QMessageBox>
#include <QUrl>
#include <QNetworkRequest>
#include <QDebug>
#include <QWidget>
#include "mainwindow.h"
#include "searchwindow.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QSqlTableModel>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonParseError>
#include <QSqlQuery>

namespace Ui {
class MainUI;
}
//char T_CabinetInfo,T_DrawerList,T_AgentiaInBox,T_AgentiaTypeList,T_UserInfo,T_AgentiaSearchResult,
//T_Task,T_CabinetStatus,T_PositionDisable,T_WaringLog,T_PositionAllocate,T_DrawerSize;//列表名
//QString sheetOperate_SwitchData;//存储处理信息

class MainUI : public QWidget
{
    Q_OBJECT

public:
    explicit MainUI(QWidget *parent = 0);
    ~MainUI();
    void postHttp(int num,QString postStr);//0 测试地址；1 获取试剂类型 2 获取在位试剂信息
    void getHttp();
    void postSwitch(int num);
    int ModelOperate;//用于指定agentiaNewsGet中对于json的解析模式选定 0 get 分解柜子信息
    int userId=1;
    int userRole;

public slots:
//    void potest();
//  void occupiedAgentiaList(int a);//获取待归还的试剂信息
private slots:
    void on_pushButton_reagentP_clicked();

    void on_pushButton_reagentG_clicked();

    void on_pushButton_reagentB_clicked();
    void GPage_To_this();
    void PPage_To_this();
//    void occupiedAgentiaList(int a);
//
    void finished(QNetworkReply * reply);
    void on_pushButton_clicked();
//    void sigin_To_this();

private:
    bool messageSuccess;
    QString messageError;
    QSqlQuery query;
    int message_Acount;
    Ui::MainUI *ui;
    char error_show;//错误显示
    QString error_message;//错误信息
    QString post_Info;//发送的信息

    searchWindow *reagentGPage;
    MainWindow *reagentPPage;
    QSqlTableModel *model;
    QNetworkAccessManager *accessManager;
    void agentiaNewsGet(QJsonDocument str ,int t);//选择和切换post反馈的信息


    QString stash_M[30];//存储变量信息
    void waitTaskInfo_mainui(char a);//系统等待


};
#endif // MAINUI_H
