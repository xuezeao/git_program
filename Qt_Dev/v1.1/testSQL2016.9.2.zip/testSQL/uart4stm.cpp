

/*
 * uart4Palm.c
 *
 *  Created on: 2015-8-20
 *      Author: siemon
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <dirent.h>
#include <string.h>
#include <QSerialPort>
#include <QSerialPortInfo>
#include "mainwindow.h"
#include "uart4stm.h"
#include <QDebug>
#include <QElapsedTimer>
#include <QCoreApplication>
int DateTime[7];
int Mode_Lock[2];
int Mode_Buzzer;
int Temperature;
int Humidity;
int photosensor[2];
QSerialPort* myCom;

void waitTaskInfo(int tim)
{
    QElapsedTimer t;
    t.start();
        while(t.elapsed()<tim)
        {
            QCoreApplication::processEvents();
        }
}

bool createSerialPort(const QString &portName, unsigned int baudRate)
{
    myCom= new QSerialPort(QString("%1").arg(SERIALPORT));
    myCom->setPortName(portName);
    myCom->open(QIODevice::ReadWrite);
    myCom->setBaudRate(baudRate);
    myCom->setDataBits(QSerialPort::Data8);
    myCom->setParity(QSerialPort::NoParity);
    //myCom->setStopBits(QSerialPort::OneStop);
    return myCom->setFlowControl(QSerialPort::NoFlowControl);
}
/*
 * Check Sum
 */
char uartCheckSum(char* data, int num)
{
    char sum = 0;
    int i = 0;
    for(i = 0; i < num; i++)
        sum += *(data + i);
    return sum;
}

/**
 * Send commands.
 */

void PackageSend(QSerialPort* uartfd,int DID, struct Package1 data1, struct Package2 data2)
{

    data1.Header[0] = 0x1C;
    data1.Header[1] = 0x47;
    data1.Header[2] = 0x45;
    data1.Header[3] = 0x42;

    data1.DevID[0] = DID;

    data1.CheckSum = uartCheckSum(&data1.DevID[0],4);
    int sendLen =  data1.ExtraDataLen[0];
    if(sendLen >40 )
        sendLen = 40;


    data2.ExtraData[sendLen-1] = uartCheckSum(&data2.ExtraData[0], sendLen-1);

    QByteArray dataMsg;
    dataMsg.resize(sizeof(data1)+sizeof(data2));
    memcpy(dataMsg.data(),&data1,9);
    memcpy(dataMsg.data()+9,&data2,sendLen);
    uartfd->write(dataMsg,9+sendLen);
}


int SetSysTime(QSerialPort* uartfd,int DID,char *datetime)//0x01 设置系统时间
{
    //if(machineryFlag != 0)
    //	return 0;
    struct tm tmDisp;
    sscanf(datetime,"%d-%d-%d %d:%d:%d %d",&tmDisp.tm_year, &tmDisp.tm_mon, &tmDisp.tm_mday,
            &tmDisp.tm_hour, &tmDisp.tm_min, &tmDisp.tm_sec, &tmDisp.tm_wday);
    struct Package1 P1;
    P1.CmdID = CID_SET_TIME;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 8;

    struct Package2 P2;
    //memcpy(P2.ExtraData,disp,10);
    P2.ExtraData[0] = tmDisp.tm_year-2000;
    P2.ExtraData[1] = tmDisp.tm_mon;
    P2.ExtraData[2] = tmDisp.tm_mday;
    P2.ExtraData[3] = tmDisp.tm_hour;
    P2.ExtraData[4] = tmDisp.tm_min;
    P2.ExtraData[5] = tmDisp.tm_sec;
    P2.ExtraData[6] = tmDisp.tm_wday;

    qDebug("%d-%d-%d %d:%d:%d %d", tmDisp.tm_year, tmDisp.tm_mon, tmDisp.tm_mday,
                tmDisp.tm_hour, tmDisp.tm_min, tmDisp.tm_sec, tmDisp.tm_wday);

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}


int SetBuzzer(QSerialPort* uartfd,int DID,int Mode_Buzzer)//0x02 设置蜂鸣器 0-close;1-open
{
    struct Package1 P1;
    P1.CmdID = CID_SET_BUZZER;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x02;
    struct Package2 P2;
    P2.ExtraData[0] = Mode_Buzzer;
    PackageSend(uartfd,DID,P1, P2);
    return (0);
}


int SetDigital(QSerialPort* uartfd,int DID,int number)//0x03 设置数码管状态
{
    struct Package1 P1;
    P1.CmdID = CID_SET_DIGITAL;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 5;

    struct Package2 P2;
    P2.ExtraData[0] = number/1000;
    P2.ExtraData[1] = number%1000/100;
    P2.ExtraData[2] = number%100/10;
    P2.ExtraData[3] = number%10;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}


int SetFan(QSerialPort* uartfd,int DID,int Mode_Fan)//0x04 设置风扇状态 0-close;1-open
{
    struct Package1 P1;
    P1.CmdID = CID_SET_FAN;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x02;
    struct Package2 P2;
    P2.ExtraData[0] = Mode_Fan;
    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int SetDoorLock(QSerialPort* uartfd,int DID,int Mode_Lock1, int Mode_Lock2)//0x05 设置门锁状态 0-close;1-open
{
    struct Package1 P1;
    P1.CmdID =CID_SET_DOOR_LOCK;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x03;

    struct Package2 P2;
    P2.ExtraData[0] = Mode_Lock1;
    P2.ExtraData[1] = Mode_Lock2;

    PackageSend(uartfd,DID,P1, P2);

    return (0);
}


int RequestRTC(QSerialPort* uartfd,int DID)//0x31 请求RTC时间
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_RTC_TIME;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int RequestBuzzer(QSerialPort* uartfd,int DID) //0x32 请求蜂鸣器状态
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_BUZZER;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int RequestTemperatureHumidity(QSerialPort* uartfd,int DID) //0x33 请求温湿度
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_TEMPERATURE_HUMIDITY;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int RequestDoorLock(QSerialPort* uartfd,int DID)//0x35 请求门锁状态
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_DOOR_LOCK;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}


int SetDrawerLock(QSerialPort* uartfd,int DID)//0x11 设置抽屉锁状态
{
    struct Package1 P1;
    P1.CmdID =CID_SET_DRAWER_LOCK;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x02;

    struct Package2 P2;
    P2.ExtraData[0] = 1;

    PackageSend(uartfd,DID,P1, P2);

    return (0);
}

int SetLED(QSerialPort* uartfd,int DID,char *DataLed)//0x12 设置LED状态
{
    struct Package1 P1;
    P1.CmdID =CID_SET_LED;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x07;
    struct Package2 P2;
    for(int i=0;i<6;i++)
    {
        P2.ExtraData[i] = DataLed[i];
    }

    PackageSend(uartfd,DID,P1, P2);
    sleep(1);

    return (0);
}

int RequestDrawerLock(QSerialPort* uartfd,int DID)//0x41 请求抽屉锁状态
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_DRAWER_LOCK;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int RequestPhotosensor(QSerialPort* uartfd,int DID)//0x42 请求请求光电状态状态
{
    struct Package1 P1;
    P1.CmdID = CID_REQUEST_PHOTOSENSOR;
    P1.ErrorCode = 0;
    P1.ExtraDataLen[0] = 0x00;

    struct Package2 P2;

    PackageSend(uartfd,DID,P1, P2);
    return (0);
}

int wait4GetDrawer(int DID)
{
    int i,j;
    for(i=0;i<3;i++)
    {
        RequestDrawerLock(myCom,DID);
        for(j=0;j<10;j++)
        {
            int rtnState = readData();
            if (rtnState == STATE_DRAWER_LOCK_CLOSE)
            {
                qDebug("CLOSE");
                return DRAWER_CLOSE;
            }
            else if(rtnState == STATE_DRAWER_LOCK_OPEN)
            {
                qDebug("OPEN");
                return DRAWER_OPEN;
            }
        }
    }
    return -1;
}

int wait4OpenDrawer(int DID)
{
    int i,j;
    for(i=0;i<3;i++)
    {
        SetDrawerLock(myCom,DID);
        for(j=0;j<10;j++)
        {
            int rtnState = readData();
            if (rtnState == STATE_SET_DRAWER_LOCK)
            {
                qDebug("Send Open Drawer Command OK!");
                return 0;
            }
        }
    }
    return -1;
}

int IntoDrawer(int DID)     //开锁
{
    int i;
    int drawerState = wait4GetDrawer(DID);
    if(drawerState == DRAWER_CLOSE)
    {
        for(i = 0; i < 3; i++)
        {
            if(wait4OpenDrawer(DID))
                return -1;
            drawerState = wait4GetDrawer(DID);
            if(drawerState == -1)
                return -1;
            else if(drawerState == DRAWER_OPEN)
                return 0;
            else
            {
                if(i == 3)
                    return -1;
            }
        }
        return -1;
    }
    else if(drawerState == -1)
        return -1;
    else
        return 0;
}

void SetDataLED(int *send_positionNo,int send_LEDNum,char *DataLED,int color)//绿色 1
{
    int i;
    if(send_LEDNum!=0)
    {
        for(int ledNo = 0;ledNo < send_LEDNum;ledNo++)
        {
            if(send_positionNo[ledNo]!=0)
            {
                i=send_positionNo[ledNo]%2;
                if (i==1)
                {
                    if(color==1)
                        DataLED[send_positionNo[ledNo]/2] += 0x10;
                    else
                        DataLED[send_positionNo[ledNo]/2] += 0x20;
                }
                else
                {
                    if(color==1)
                        DataLED[send_positionNo[ledNo]/2-1] += 0x01;
                    else
                        DataLED[send_positionNo[ledNo]/2] += 0x20;
                }
            }
        }
    }
}

int wait4LED(int DID,char *DataLED)//设置LED
{
    int i,j;
    for(i=0;i<3;i++)
    {
        SetLED(myCom,DID,DataLED);
        for(j=0;j<10;j++)
        {
            int rtnState = readData();
            if (rtnState == STATE_SET_LED)
            {
                qDebug("Send Set LED OK!");
                return 0;
            }
        }
    }
    return -1;
}

int wait4Photosensor(int DID)//检测光电
{
    int i,j;
    for(i=0;i<3;i++)
    {
        RequestPhotosensor(myCom,DID);
        for(j=0;j<10;j++)
        {
            int rtnState = readData();
            if (rtnState == STATE_REQUEST_PHOTOSENSOR)
            {
                qDebug("Get photosensor");
                return 0;
            }
        }
    }
    return -1;
}

int takeAct(int DID,int *send_positionNo,int send_LEDNum)
{
    int Error_photosensor[16];
    int Error_Num;
    char DataLED[5];
    //查询任务前光电状态
    if(wait4Photosensor(DID)==-1)
        return -1;
    unsigned short ledPosPre = 0;
    ledPosPre = (photosensor[0] << 8) + photosensor[1];
    unsigned short ledChangePos = 0;
    for(int i=0;i<send_LEDNum;i++)
    {
        ledChangePos += (1 << (16 - send_positionNo[i]));
    }

    //开抽屉
    if(IntoDrawer(DID)==-1)
        return -1;
    //设置灯
    SetDataLED(send_positionNo,send_LEDNum,DataLED,1);
    if(wait4LED(DID,DataLED)==-1)
        return -1;

    unsigned short ledPosNext = 0;
    ledPosNext = (photosensor[0] << 8) + photosensor[1];

    while((ledPosNext ^ ledPosPre) != ledChangePos)
    {
        if(wait4GetDrawer(DID)==DRAWER_CLOSE)
            return -1;
        if(wait4Photosensor(DID)==-1)
            return -1;
        Error_Num=0;
        memset(Error_photosensor,0,5);
        memset(DataLED,0,5);
        ledPosNext = (photosensor[0] << 8) + photosensor[1];
        //判断光电状态改变是否正确，改变灯状态
        unsigned short ledAlarmPos = (ledPosNext ^ ledPosPre) & (~ledChangePos);
        Error_Num = 0;
        if(ledAlarmPos)
        {
            for(int i = 0; i < 16; i++)
            {
                if(ledAlarmPos & 0x8000)
                    Error_photosensor[Error_Num++] = i + 1;
                ledAlarmPos <<= 1;
            }
        }
        memset(DataLED,0,5);
        SetDataLED(Error_photosensor,Error_Num,DataLED,2);
        SetDataLED(send_positionNo,send_LEDNum,DataLED,1);
        if(wait4LED(DID,DataLED)==-1)
            return -1;

    }
    memset(DataLED,0,5);
    if(wait4LED(DID,DataLED)==-1)
        return -1;
    return 0;
}

int readData()
{
    QByteArray alldata;
    int i,j;
    for(j=0;j<20;j++)
    {
        waitTaskInfo(5);
        if(myCom->bytesAvailable()>8)
        {
            alldata = myCom->readAll();
            for(i=0;i<=alldata.size();i++)
             {
                 if((alldata.at(i) == 0x1b)&&(alldata.at(i+1) == 0x46)&&(alldata.at(i+2) == 0x44)&&(alldata.at(i+3) == 0x41))
                     break;
                 else if((alldata.at(i) == 0x1D)&&(alldata.at(i+1) == 0x48)&&(alldata.at(i+2) == 0x46)&&(alldata.at(i+3) == 0x43))
                     break;
                 else if((alldata.at(i) == 0x1b)&&(alldata.at(i+1) == 0x46)&&(alldata.at(i+2) == 0x44)&&(alldata.at(i+3) == 0x41))
                     break;
                 else if((alldata.at(i) == 0x1B)&&(alldata.at(i+1) == 0x46)&&(alldata.at(i+2) == 0x44)&&(alldata.at(i+3) == 0x41))
                     break;
             }
            int pHead = i;
            int nread;
            unsigned char CID = 0;
            int exDataLen = 0;
            unsigned char checkSum = 0;
            for(i = pHead+4; i < pHead+8; i++)
                checkSum += alldata.at(i);
            if(alldata.at(i) != checkSum)
            {
                qDebug("P1 Check Sum Error!\n");
                nread = 0;
                alldata.clear();
                //STATE_RTN = STATE_ERROR;
            }
            else
            {
                qDebug("P1 Check Sum Confirmed!\n");
                CID=alldata.at(pHead+5);
                exDataLen = alldata.at(pHead+6);
                //有扩展帧
                if(exDataLen>0)
                {
                    qDebug("Extra data length: %d\n", exDataLen);
                    checkSum = 0;
                    for(i = pHead+9;i<pHead+exDataLen+8;i++)
                        checkSum += alldata.at(i);
                    if(alldata.at(pHead+exDataLen+8) == checkSum)
                    {
                        nread = 0;
                        if(CID == CID_REQUEST_DOOR_LOCK)
                        {
                            if(alldata.at(pHead+9)==0)
                            {
                                return STATE_DOOR1_LOCK_CLOSE;
                                qDebug("Door1 Lock OPEN!");
                            }
                            else
                            {
                                return STATE_DOOR1_LOCK_OPEN;
                                qDebug("Door1 Lock CLOSE!");
                            }

                        }
                        else if(CID == CID_REQUEST_DRAWER_LOCK) //0x41
                        {
                            if(alldata.at(pHead+9)==0)
                            {
                                return STATE_DRAWER_LOCK_CLOSE;
                                qDebug("Door1 Lock CLOSE!");
                            }
                            else
                            {
                                return STATE_DRAWER_LOCK_OPEN;
                                qDebug("Door1 Lock OPEN!");
                            }

                        }
                        else if(CID==CID_REQUEST_PHOTOSENSOR)
                        {
                            photosensor[0]=alldata.at(pHead+9);
                            photosensor[1]=alldata.at(pHead+10);
                            return STATE_REQUEST_PHOTOSENSOR;
                            qDebug("Request Photosensor!");

                        }
                        else
                            return STATE_ERROR;

                    }
                    else
                    {
                        qDebug("P2 Check Sum Error: %x\n", checkSum);
                        nread = 0;
                        return STATE_ERROR;
                    }
                }
                //没有扩展帧
                else
                {
                    if(CID == CID_SET_DRAWER_LOCK )                 //0x11
                        return STATE_SET_DRAWER_LOCK;
                    else if(CID==CID_SET_LED)                       //0x12
                    {
                        return STATE_SET_LED;
                        qDebug("0x12");
                    }
                    else if(CID==CID_SET_DOOR_LOCK)               //0x05
                    {
                        return STATE_SET_DOOR_LOCK;
                        qDebug("0x12");
                    }
                    else
                        return STATE_ERROR;
                }
            }
        }
    }
    return STATE_ERROR;
}
