#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlTableModel>
#include <QSqlRelation>
#include <QDebug>
#include <QModelIndex>
#include <QTimer>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDateTime>
#include <QSqlRelationalDelegate>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    popupwindow = new popupPage;
    model = new QSqlRelationalTableModel(this);
    model2=new QSqlRelationalTableModel(this);
    timer = new QTimer;
    ui->setupUi(this);
    ui->centralWidget->setObjectName("centralWidget");
    ui->centralWidget->setStyleSheet(  "#centralWidget{"
                                     "font-size:16px;"
                                     "border-image:url(:/image/background3.bmp);"
                                     "}");
//    this->showFullScreen();//主屏幕最大化
    getSheetAddShow();
    connect(timer,SIGNAL(timeout()),this,SLOT(auto_AddRow()));
    connect(popupwindow,SIGNAL(backplacepage()),this,SLOT(returnBack()));

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::auto_AddRow()//自增行数
{
    QDateTime locationTime = QDateTime::currentDateTime();//获取当日日期
    QString str = locationTime.toString("yyyy.M.d");//设置日期格式

    int rowNum = model->rowCount();//获得表的行数

    QSqlQuery query;
    query.exec(QString("select * from T_Task where rowid")//从id=rownum中选中所有属性 '*' /也可指定 'name'
               );//选中表格中最后一行并执行操作exec，没有经过exec的都是没有执行
    query.last();//指向最后表格
    QString bottleCapacityValue = query.value(4).toString();//试剂容量
    int agentiaIdValue = query.value(2).toInt();//试剂id



    qDebug()<<agentiaIdValue<<"  "<<bottleCapacityValue<<"   "/*<<drawerNameValue*/;

    if(/*drawerNameValue >="A"&&*/agentiaIdValue>=1&&bottleCapacityValue>="1")//只有当名字、规格和容量都输入之后才会自动加一行
     {
        qDebug() << "OK";
        model->insertRow(rowNum); //添加一行
        model->setData(model->index(rowNum,6),str);//id 已经设为关键字段，自增一行
//        model->setData(model->index(rowNum,7),"未放");//id 已经设为关键字段，自增一行
//         model->submitAll();
    }
    else
   {     qDebug()<< "NO" ;

}


}
void MainWindow::getSheetAddShow()
{


//    int rowNum = model->rowCount(); //获得表的行数


    model->setEditStrategy(QSqlTableModel::OnFieldChange);//自保持模式
  //  model->select(); //选取整个表的所有行
    model->setTable("T_Task");
    model2->setTable("T_Task_Operate");
    //不显示name属性列,如果这时添加记录，则该属性的值添加不上
//     model->select();
//    model->setRelation(8,QSqlRelation("drawerSizeOption","id","id"));//外键
//    model->setHeaderData(8,Qt::Horizontal,QObject::tr("drawerSize"));
//    model->setRelation(5,QSqlRelation("reagentModel","id","id"));
//    ui->tableView_showEnter->setModel(model);
//    model->select();
//    model->setHeaderData(0,Qt::Horizontal,QObject::tr("id"));
//    model->setHeaderData(1,Qt::Horizontal,QObject::tr("试剂名称"));
//    model->setHeaderData(2,Qt::Horizontal,QObject::tr("容量 ml"));
//    model->setHeaderData(6,Qt::Horizontal,QObject::tr("类型"));
//    model->removeColumn(2);
    model->select();
    model2->select();
    ui->tableView_showEnter->setModel(model);
    ui->tableView_searchWin->setModel(model2);
    ui->tableView_showEnter->setItemDelegate(new QSqlRelationalDelegate(ui->tableView_showEnter));
    //使其不可编辑
    ui->tableView_searchWin->setItemDelegate(new QSqlRelationalDelegate(ui->tableView_showEnter));
    // ui->tableView_showEnter->setEditTriggers(QAbstractItemView::NoEditTriggers);
//    ui->tableView_showEnter->setItemDelegate(new QSqlRelationalDelegate(ui->tableView_showEnter));



}

void MainWindow::on_pushButton_del_clicked()
{
    //获取选中的行
//       QSqlQuery query;
//    model->setTable("placeDurg");
//     model->removeColumn(1);
      model->setEditStrategy(QSqlTableModel::OnManualSubmit);//进入不提交不保存模式
      timer->stop();

//     model->select(); //选取整个表的所有行
       int curRow = ui->tableView_showEnter->currentIndex().row();
//        qDebug()<<curRow;
       //删除该行
        model->removeRow(curRow);

       int ok = QMessageBox::warning(this,tr("删除当前行!"),tr("你确定"
                                                    "删除当前行吗？"),
                                     QMessageBox::Yes,QMessageBox::No);
       if(ok == QMessageBox::No)
       {
          model->revertAll(); //如果不删除，则撤销

       }
       else
       {
          model->submitAll(); //否则提交，在数据库中删除该行
//           query.exec(QString("delete from placeDurg where rowid =%1").arg(curRow));

       }
      model->setEditStrategy(QSqlTableModel::OnFieldChange);//恢复原来自保持模式
      timer->start();
}



void MainWindow::on_pushButton_placeChest_clicked()
{
//    this->close();
    popupwindow->show();
    popupwindow->selectModel(1);

    timer->stop();
    popupwindow->acount=1;

}
void MainWindow::returnBack()
{
    this->show();
    popupwindow->close();
    model->setTable("T_Task");
    model->removeColumn(1);
    model->select();
    timer->start();
}

void MainWindow::on_commandLinkButton_clicked()
{
    emit toMainChoice();
    timer->stop();
}

void MainWindow::on_pushButton_clicked()
{
    model2->setTable("T_Task_Operate");
    QString reagentName = ui->lineEdit_putIN->text();//获取搜索框内容
    if(reagentName=="")
    {
        model->setTable(QString("%1").arg("T_Task_Operate"));

    }else

        model->setFilter(QString("agentiaName like '%%1%'").arg(reagentName));//筛选结果
    model->select();//显示
    qDebug()<<QString("agentiaName like '%%1%'").arg(reagentName);

}
