#include "popuppage.h"
#include "ui_popuppage.h"
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QDebug>
#include <QString>
#include <QModelIndex>
#include <QTextCodec>
#include <QJsonArray>
/********************/
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QThread>
#include <QObject>
#include <QThread>
#include <string.h>

#include "uart4stm.h"
#include <unistd.h>
#include <QElapsedTimer>



popupPage::popupPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::popupPage)
{
    ui->setupUi(this);
    accessManager_here =new QNetworkAccessManager(this);
    model = new QSqlTableModel(this);
    acount=1;

    connect(accessManager_here,SIGNAL(finished(QNetworkReply*)),this,SLOT(finished(QNetworkReply*)));
}


void popupPage::selectModel(int num)
{
    switch (num)
    {
        case 1 : sheetName="T_Task_Operate",modelChoice=1;break;//入柜
        case 2 : sheetName="T_Task_Operate",modelChoice=2;break;//取
        case 3 : sheetName="T_Task_return_opetation",modelChoice=3;break;//还
        default:
            break;
    }

//    showmain();//因为更新比较慢，在这里确保一定更新了

    model->setTable(QString("%1").arg(sheetName));

    model->submitAll();

    model->setEditStrategy(QSqlTableModel::OnFieldChange);//自保持模式


    model->setTable(QString("%1").arg(sheetName));



    if(modelChoice==2)
    {
        model->select();
        ui->tableView->setModel(model);
        ui->label->hide();
        ui->label_2->hide();
        ui->label_3->hide();
        ui->textBrowser_showReagentlocation->hide();
        ui->textBrowser_showReagentName->hide();
        ui->textBrowser_showReagentVolume->hide();
        ui->tableView->show();
    }else{
        ui->label->show();
        ui->label_2->show();
        ui->label_3->show();
        ui->textBrowser_showReagentlocation->show();
        ui->textBrowser_showReagentName->show();
        ui->textBrowser_showReagentVolume->show();
        ui->tableView->hide();
        showNeedPlaceReagent();

    }




}

popupPage::~popupPage()
{
    delete ui;



}

void popupPage::on_pushButton_backPreviousOption_clicked()//返回入柜编辑窗口
{
    if(modelChoice==1)
        emit backplacepage();
    if(modelChoice!=1)
        emit backGPage();
}


void popupPage::showNeedPlaceReagent()
{
    qDebug()<<acount<<"---------------------------";
    acount=1;
    a[0]=ba;
    ba++;
    QSqlQuery query;
    QString showName;
    QString sendSize;
    QString Position_Drawer;
    int attributV;
    QString showVolume ;
    query.exec(QString("select * from '%1' where rowid = '%2'")//从id=rownum中选中所有属性 '*' /也可指定 'name'
                 .arg(sheetName).arg(acount));//选中表格中最后一行并执行操作exec，没有经过exec的都是没有执行
    query.next();//指向下一行表格
    qDebug()<<acount<<"********************";
    model->setFilter(QString("rowid = '%1'").arg(acount));//取得所要显示的信息
    model->select();


        if(modelChoice==3)//还
        {
             showName = query.value(3).toString();//名字
             attributV= query.value(12).toInt();//试剂类别
             showVolume = query.value(4).toString();//dose
             send_positionNo=query.value(8).toInt();
             send_drawerNo=query.value(6).toInt();
             qDebug()<<send_positionNo<<"------------------"<<send_drawerNo;
             Position_Drawer = "抽屉号："+query.value(6).toString()+"位置："+query.value(8).toString();
        }else{
            showName="酒精";
            showName = query.value(3).toString();//名字
            sendSize = query.value(9).toString();
            attributV= query.value(12).toInt();//试剂类别
            showVolume = query.value(4).toString();//dose
        }


        if(showName==""&&acount!=1)//执行完毕返回上一层界面
        {
            int ok = QMessageBox::warning(this,tr("摆放完成"),tr("ok"),QMessageBox::Yes,QMessageBox::No);
            if(ok==QMessageBox::Yes)
            {
                if(modelChoice==1)
                    emit backplacepage();
                else
                    emit backGPage();
            }
                acount=1;


        }




        if(attributV!='\0'&&sendSize!='\0'&&modelChoice==1)//入柜
        {
            QJsonObject json_PutInOk;
            json_PutInOk.insert("cabinetNo",QString("AABBCCDD"));//生成JSON
            json_PutInOk.insert("drawerSize",sendSize);
            json_PutInOk.insert("attribute",attributV);

            document.setObject(json_PutInOk);
            QByteArray byte_array=document.toJson(QJsonDocument::Compact);
            QString json_str(byte_array);



            postHttp_P(1,json_str);
            modelSwitch=0;
            waitTaskInfo(100);


        }
            if(positionInfo=="0")
            {
                int ok = QMessageBox::warning(this,tr("error"),tr("无法收到正确信息系统将返回上一界面"
                                                                      "无法收到正确信息系统将返回上一界面"),
                                                 QMessageBox::Yes,QMessageBox::No);
                   if(ok == QMessageBox::No||ok == QMessageBox::Yes)
                   {
                       if(modelChoice==1)
                       {
                           emit backplacepage();
                       }
                       if(modelChoice==3)
                       {
                           emit backReturn();
                       }
                   }
                   acount=0;
            }



        qDebug()<<positionInfo<<"2222222222222288888888888888888";

        qDebug()<<showName<<"  "+showVolume<<"  "+sendSize;
        if(modelChoice==3)
        {
            ui->textBrowser_showReagentName->setText(showName);
            ui->textBrowser_showReagentVolume->setText(showVolume);
            ui->textBrowser_showReagentlocation->setText(Position_Drawer);
        }else
        {
            ui->textBrowser_showReagentName->setText(showName);
            ui->textBrowser_showReagentVolume->setText(showVolume);
            ui->textBrowser_showReagentlocation->setText(positionInfo);
        }

        switch (send_drawerNo) {
        case 1: send_bool_drawerNo=0x01;
            break;
        case 2: send_bool_drawerNo=0x01;
            break;
        case 3: send_bool_drawerNo=0x01;
            break;
        default:
            break;
        }

//         if(modelChoice==1)
//         {
//             if(IntoDrawer(0x01)==-1)
             int a[1]={send_positionNo};
             if(takeAct(send_bool_drawerNo,a,1))//return 0 正常，-1 不正常
                 qDebug("ERROR");
//         }


         acount++;
}
void popupPage::creatPostInfo(int a)//暂时不用
{

}

void popupPage::waitTaskInfo(char a)
{
//    QElapsedTimer t;//主程序等待
//    t.start();
//     while(t.elapsed() < a)
//     {
//         QCoreApplication::processEvents();
//     }

     QEventLoop eventloop;
     QTimer::singleShot(a, &eventloop, SLOT(quit()));
     eventloop.exec();
}

void popupPage::on_pushButton_placedNext_clicked()
{
//    QString sheetName="placeDurg";
        QSqlQuery query;
//        model->setEditStrategy(QSqlTableModel::OnFieldChange);//自保持模式

//        model->setTable(QString("%1").arg(sheetName));
//    model->setData(model->index(0,7),stash_P[3]);//更改状态
//    model->setData(model->index(0,8),stash_P[4]);//更改状态
//    model->setData(model->index(0,10),stash_P[0]);//更改状态
//    model->setData(model->index(0,11),stash_P[1]);//更改状态
//    model->setData(model->index(0,12),stash_P[2]);//更改状态
//  model->setData(model->index(rowNumIndex-1,3),"已放");//为自增位置预留位置
//    model->select();
//    model->submitAll();
//    RequestDoorClock(myCom,0xFF);
//    qDebug("getCLOCK");

    if(modelChoice==1)//入柜
    {
        QJsonObject json;
        json.insert("userId",QString("1"));//生成JSON
        json.insert("agentiaTypeId",1);
        json.insert("bottleCapacity",QString("500ml"));
        json.insert("dose",QString("400ml"));
        json.insert("expireDate",QString("2017.1.1"));
        json.insert("positionId",6);

        document.setObject(json);
        QByteArray byte_array=document.toJson(QJsonDocument::Compact);
        QString json_str(byte_array);

        postHttp_P(2,json_str);
        modelSwitch=1;
        showNeedPlaceReagent();
    }
    if(modelChoice==3)//归还
    {
        QJsonObject json;
        json.insert("userId",QString("1"));//生成JSON
        json.insert("agentiaId",1);
//        json.insert("bottleCapacity",QString("500ml"));
        json.insert("dose",QString("300ml"));
//        json.insert("expireDate",QString("2017.1.1"));
        json.insert("positionId",1);

        document.setObject(json);
        QByteArray byte_array=document.toJson(QJsonDocument::Compact);
        QString json_str(byte_array);

        postHttp_P(3,json_str);
        modelSwitch=2;
        showNeedPlaceReagent();
    }


//    if(stash_P[5]=="false")
//    {
//        int ok = QMessageBox::warning(this,tr("error"),tr("无法收到正确信息系统将返回上一界面"
//                                                              "无法收到正确信息系统将返回上一界面"),
//                                         QMessageBox::Yes,QMessageBox::No);
//           if(ok == QMessageBox::No||ok == QMessageBox::Yes)
//           {

//           }
//           emit backplacepage();
//    }
    if(modelChoice==2)//取
    {
//        int i=1;
//        int rowColumn=model->rowCount();
//        while (i<rowColumn) {

//        }
        QJsonObject json;
        json.insert("userId",QString("1"));//生成JSON
        json.insert("agentiaId",1);
        json.insert("positionId",6);

        document.setObject(json);
        QByteArray byte_array=document.toJson(QJsonDocument::Compact);
        QString json_str(byte_array);

        postHttp_P(4,json_str);
        modelSwitch=3;
        showNeedPlaceReagent();
//        }
    }
    waitTaskInfo(100);

    positionInfo="0";
    query.exec(QString("DELETE * FROM T_PositionAllocate"));
}
void popupPage::getHttp()
{
    QNetworkRequest *request=new QNetworkRequest();
//    request->setUrl(QUrl("http://121.41.78.9:3000/arm/getTest"));
    request->setUrl(QUrl(QString("http://localhost:3000/arm/initialInfo/AABBCCDD")));
    accessManager_here->get(*request);
}


void popupPage::on_pushButton_jumpThisOption_clicked()
{
     showNeedPlaceReagent();
}

void popupPage::postHttp_P(int num,QString postStr)
{
    QString address;

    switch (num) {
    case 0 :address="postTest";
        break;
    case 1 :address="allocPosition";//获取地址信息
        break;
    case 2 :address="putIn";//反馈入柜完成
        break;
    case 3 :address="giveBack";//反馈归还完成
        break;
    case 4 :address="takeOut";//取的任务完成

//    case 4 :address="disablePosition";//禁用格子
//        break;
    default:
        break;
    }
    QNetworkRequest *request = new QNetworkRequest();
//    request->setUrl(QUrl("http://121.41.78.9:3000/arm/postTest"));
    request->setUrl(QUrl(QString("http://localhost:3000/arm/%1").arg(address)));
    request->setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
//    QString postStr = "{\"username\":\"james\",\"password\":\"attack\"}";
    QByteArray postData = postStr.toUtf8();
    qDebug()<<QObject::tr(postData);
    accessManager_here->post(*request,postData);
//    QByteArray postData = ui->textEdit->toPlainText().toUtf8();
//    qDebug()<<QObject::tr(postData);
//    accessManager->post(*request,postData);
}
/*********************************************************************/
void popupPage::finished(QNetworkReply *reply)
{
//   QMessageBox *msgBox = new QMessageBox(this);

    if(reply->error() == QNetworkReply::NoError)
    {
//        QTextCodec *codec = QTextCodec::codecForName("GBK");//显示中文
        QTextCodec *codec = QTextCodec::codecForName("utf-8");
       QString all = codec->toUnicode(reply->readAll());
        QJsonDocument all_switch=QJsonDocument::fromJson(all.toUtf8());
        postS_GetPosition(all_switch,modelSwitch);


    }
    else
    {

        qDebug()<<"handle errors here";

    }
    reply->deleteLater();
//    msgBox->exec();
}
void popupPage::postS_GetPosition(QJsonDocument t,char t1)
{
    QJsonObject sett1=t.object();
    if(t1==0)//入柜位置信息
    {
        QJsonValue i1=sett1["positionNo"].toInt();
        stash_P[0]=QString::number(i1.toInt());
        send_positionNo=i1.toInt();

        QJsonValue i2=sett1["positionName"].toString();
        stash_P[1]=i2.toString();

        QJsonValue i3=sett1["positionId"].toInt();
        stash_P[2]=QString::number(i3.toInt());
        send_positionNo=i3.toInt();


        QJsonValue i4=sett1["drawerNo"].toInt();
        stash_P[3]=QString::number(i4.toInt());
        send_drawerNo=i4.toInt();

        QJsonValue i5=sett1["drawerName"].toString();
        stash_P[4]=i5.toString();

        qDebug()<<stash_P[0]+" "+stash_P[1]+"  "+stash_P[2]+"---"+stash_P[3]+"******"+stash_P[4]+"***";
        postStash_P(0);
    }
    if(t1==1)//入柜完成反馈
    {
        QJsonValue i1=sett1["success"].toBool();
        if(i1==true)
            stash_P[5]="true";
        else
            stash_P[5]="false";
        qDebug()<<stash_P[5];
    }
    if(t1==2)//归还完成反馈
    {
        QJsonValue i1=sett1["success"].toBool();
        if(i1==true)
            stash_P[5]="true";
        else
            stash_P[5]="false";
        qDebug()<<stash_P[5];
    }
    if(t1==3)//取完成反馈
    {
        QJsonValue i1=sett1["success"].toBool();
        if(i1==true)
            stash_P[5]="true";
        else
            stash_P[5]="false";
        qDebug()<<stash_P[5];
    }
}

void popupPage::postStash_P(int num)
{

    QSqlQuery query;
    if(num==0)
    {
            query.prepare("insert into T_PositionAllocate (positionNo,positionName,positionId,drawerNo,drawerName) values (?,?,?,?,?)");
            query.addBindValue(stash_P[0]);
            query.addBindValue(stash_P[1]);
            query.addBindValue(stash_P[2]);
            query.addBindValue(stash_P[3]);
            query.addBindValue(stash_P[4]);
            query.exec();

            positionInfo="抽屉号："+stash_P[3]+",位置："+stash_P[0];

            qDebug()<<positionInfo;
    }

}

/*************************************/

