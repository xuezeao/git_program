#include "mainui.h"
#include "ui_mainui.h"
#include <QTextCodec>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QModelIndex>
#include <QVariantMap>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QThread>
#include <QObject>
#include <QThread>
#include <string.h>

#include "uart4stm.h"
#include <unistd.h>
#include <QElapsedTimer>


int sheetOperate_Model;//选择发送模式
uint count_sheet;
//QString sheetOperate_SwitchData;//存储处理信息
QString stash[1000];
MainUI::MainUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainUI)
{
    ui->setupUi(this);
//    createSerialPort("com3", 38400);
//    threadRead.start();
//    qDebug("SerialPort open!");

    model = new QSqlTableModel(this);
    reagentGPage = new searchWindow;
    reagentPPage = new MainWindow;
    accessManager =new QNetworkAccessManager(this);
    ui->tag1->setObjectName("tag1");
    ui->tag1->setStyleSheet(  "#tag1{"
                                     "font-size:16px;"
                                     "border-image:url(:/image/background3.bmp);"
                                     "}");
    ui->tag2->setObjectName("tag2");
    ui->tag2->setStyleSheet("#tag2{"
                              "font-size:16px;"
                              "border-image:url(:/image/background2.bmp);"
                              "}");
    ui->tag3->setObjectName("tag3");
    ui->tag3->setStyleSheet("#tag3{"
                              "font-size:16px;"
                              "border-image:url(:/image/background2.bmp);"
                              "}");


//    this->showFullScreen();//主屏幕最大化
    connect(accessManager,SIGNAL(finished(QNetworkReply*)),this,SLOT(finished(QNetworkReply*)));
    connect(reagentGPage,SIGNAL(GPageToMainUi()),this,SLOT(GPage_To_this()));
    connect(reagentPPage,SIGNAL(toMainChoice()),this,SLOT(PPage_To_this()));



//    QString postStr = "{\"username\":\"james\",\"password\":\"attack\"}";

//    getHttp();
//    ModelOperate=0;
//    post_Info="0";
//    postHttp(1,post_Info);//获取所有信息
//    ModelOperate=1;

    postHttp(3,"0");
    waitTaskInfo_mainui(300);
}

MainUI::~MainUI()
{
    delete ui;
}

void MainUI::waitTaskInfo_mainui(char a)
{
    QElapsedTimer t;//主程序等待
    t.start();
     while(t.elapsed() < a)
     {
         QCoreApplication::processEvents();
     }
}

void MainUI::on_pushButton_reagentP_clicked()
{
    this->close();
    reagentPPage->show();
    reagentPPage->timer->start(1000);
}

void MainUI::on_pushButton_reagentG_clicked()
{
    this->close();
    reagentGPage->show();
    reagentGPage->searchSelect(2);
}

void MainUI::on_pushButton_reagentB_clicked()
{

    this->close();
    reagentGPage->show();
    reagentGPage->searchSelect(3);
}

void MainUI::GPage_To_this()
{
    this->show();
    reagentGPage->close();
}

void MainUI::PPage_To_this()
{
    this->show();
    reagentPPage->close();
}

/******************************get/Http***************************************/
void MainUI::getHttp()
{
    QNetworkRequest *request=new QNetworkRequest();
//    request->setUrl(QUrl("http://121.41.78.9:3000/arm/getTest"));
    request->setUrl(QUrl(QString("http://localhost:3000/arm/initialInfo/%1").arg(CABINETNO)));
    accessManager->get(*request);
}
void MainUI::postHttp(int num,QString postStr)
{
    QString address;

    switch (num) {
    case 0 :address="postTest";//测试地址
        break;
    case 1 :address="availableAgentiaList";//获取再位试剂列表
        postStr=QString("{\"cabinetNo\":\"%1\"}").arg(CABINETNO);
        break;
    case 2 :address="agentiaTypeList";//获取试剂类型列表
        ModelOperate=2;
        break;
    case 3 :address="occupiedAgentiaList";//获取待归还试剂
        postStr=QString("{\"userId\":%1,\"cabinetNo\":\"%2\"}").arg(userId).arg(CABINETNO);
        ModelOperate=3;
        break;
    default:
        break;
    }
    QNetworkRequest *request = new QNetworkRequest();
//    request->setUrl(QUrl("http://121.41.78.9:3000/arm/postTest"));
//    request->setUrl(QUrl("http://localhost:9090/test"));
    request->setUrl(QUrl(QString("http://localhost:3000/arm/%1").arg(address)));
    request->setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
//    QString postStr = "{\"username\":\"james\",\"password\":\"attack\"}";
    QByteArray postData = postStr.toUtf8();
    qDebug()<<QObject::tr(postData);
    accessManager->post(*request,postData);
//    QByteArray postData = ui->textEdit->toPlainText().toUtf8();
//    qDebug()<<QObject::tr(postData);
//    accessManager->post(*request,postData);
}
/*********************************************************************/
void MainUI::finished(QNetworkReply *reply)
{
   QMessageBox *msgBox = new QMessageBox(this);

    if(reply->error() == QNetworkReply::NoError)
    {
//        QTextCodec *codec = QTextCodec::codecForName("GBK");//显示中文
         QTextCodec *codec = QTextCodec::codecForName("utf-8");


        QString all = codec->toUnicode(reply->readAll());
        QJsonDocument all_switch_MainUi=QJsonDocument::fromJson(all.toUtf8());
        agentiaNewsGet(all_switch_MainUi,ModelOperate);

        qDebug()<<all;

    }
    else
    {
        msgBox->setText(reply->errorString());
        qDebug()<<"handle errors here";

    }
    reply->deleteLater();

}

void MainUI::agentiaNewsGet(QJsonDocument str, int t)
{
    QJsonObject sett1=str.object();
    qDebug()<<t;
    if(t==0)//存储柜子信息和抽屉信息
    {
        QJsonValue i1=sett1["cabinetName"].toString();
        qDebug()<<i1.toString();
        stash_M[0]=i1.toString();

        QJsonValue i2=sett1["groupId"].toInt();
        qDebug()<<QString::number(i2.toInt());
        stash_M[1]=QString::number(i2.toInt());

        QJsonValue i3=sett1["groupName"].toString();
        qDebug()<<i3.toString();
        stash_M[2]=i3.toString();

        QJsonValue i4=sett1["drawerAmount"].toInt();
        message_Acount=i4.toInt();
        qDebug()<<QString::number(i4.toInt());
        stash_M[3]=QString::number(i4.toInt());


        query.prepare("insert into T_CabinetInfo (cabinetName,groupId,groupName,drawerAmount) values (?,?,?,?)");
        query.addBindValue(stash_M[0]);
        query.addBindValue(stash_M[1]);
        query.addBindValue(stash_M[2]);
        query.addBindValue(stash_M[3]);
        query.exec();


        QJsonArray i5=sett1["drawerList"].toArray();
        for(int i=0;i<message_Acount;i++)
        {
            QJsonObject i6=i5[i].toObject();
            QJsonValue i7=i6["drawerNo"].toInt();
            stash_M[4]=QString::number(i7.toInt());

            QJsonValue i8=i6["drawerName"].toString();
            stash_M[5]=i8.toString();

            QJsonValue i9=i6["drawerSize"].toString();
            stash_M[6]=i9.toString();

            QJsonValue i10=i6["positionAmount"].toInt();
            stash_M[7]=QString::number(i10.toInt());

            QJsonValue i11=i6["attribte"].toInt();
            stash_M[8]=QString::number(i11.toInt());
            qDebug()<<i7<<"-------"<<i8<<"----"<<i9<<"-------"<<i10<<"----------"<<i11;

            query.prepare("insert into T_DrawerList (drawerNo,drawerName,drawerSize,positionAmount,attribute) values (?,?,?,?,?)");
            query.addBindValue(stash_M[4]);
            query.addBindValue(stash_M[5]);
            query.addBindValue(stash_M[6]);
            query.addBindValue(stash_M[7]);
            query.addBindValue(stash_M[8]);
            query.exec();

        }

    }
    if(t==1)//存储所有在柜药剂信息
    {
        QJsonValue i1=sett1["success"].toBool();
        qDebug()<<i1.toBool();
            QJsonValue i2=sett1["errorMessage"].toString();
            qDebug()<<i2.toString();
            error_message=i2.toString();
         if(i1.toBool()==true)
         {
            qDebug()<<"occupiedAgentiaList  OK";
            QJsonValue i3=sett1["amount"].toInt();
            message_Acount=i3.toInt();
            qDebug()<<message_Acount;
            QJsonArray i5=sett1["agentiaList"].toArray();
            for(int i=0;i<message_Acount;++i)
            {
                 QJsonObject i6=i5[i].toObject();
                 QJsonValue i7=i6["agentiaId"].toInt();
                 stash_M[0]=QString::number(i7.toInt());

                 QJsonValue i8=i6["bottleCapacity"].toString();
                 stash_M[1]=i8.toString();

                 QJsonValue i9=i6["dose"].toString();
                 stash_M[2]=i9.toString();


                 QJsonValue i10=i6["expiryDate"].toString();
                 stash_M[3]=i10.toString();

                 QJsonValue i11=i6["drawerNo"].toInt();
                 stash_M[4]=QString::number(i11.toInt());

                 QJsonValue i12=i6["drawerName"].toString();
                 stash_M[5]=i12.toString();

                 QJsonValue i13=i6["positionNo"].toInt();
                 stash_M[6]=QString::number(i13.toInt());

                 QJsonValue i14=i6["positionName"].toString();
                 stash_M[7]=i14.toString();

                 QJsonValue i15=i6["positionId"].toInt();
                 stash_M[8]=QString::number(i15.toInt());

                 QJsonValue i16=i6["attribute"].toInt();
                 stash_M[9]=QString::number(i16.toInt());

                 query.prepare("insert into T_AgentiaInBox (agentiaId,bottleCapacity,dose,expiryDate,drawerNo,drawerName,positionNo,positionName,positionId,attribute) values (?,?,?,?,?,?,?,?,?,?)");
                 query.addBindValue(stash_M[0]);
                 query.addBindValue(stash_M[1]);
                 query.addBindValue(stash_M[2]);
                 query.addBindValue(stash_M[3]);
                 query.addBindValue(stash_M[4]);
                 query.addBindValue(stash_M[5]);
                 query.addBindValue(stash_M[6]);
                 query.addBindValue(stash_M[7]);
                 query.addBindValue(stash_M[8]);
                 query.addBindValue(stash_M[9]);
                 query.exec();
            }
//            query.exec(QString("select * from T_AgentiaInBox ORDER BY agentiaId ASC"));


         }
         else
         {
             error_show=1;

         }

    }
    if(t==2){
        ;
    }
    if(t==3)
    {
        QJsonValue i1=sett1["success"].toBool();
        qDebug()<<i1.toBool();
        QJsonValue i2=sett1["errorMessage"].toString();
        qDebug()<<i2.toString();
        error_message=i2.toString();
        if(i1.toBool()==true)
        {
           qDebug()<<"occupiedAgentiaList  OK";
           QJsonValue i3=sett1["amount"].toInt();
           message_Acount=i3.toInt();
           qDebug()<<message_Acount;
           QJsonArray i5=sett1["agentiaList"].toArray();
           for(int i=0;i<message_Acount;++i)
           {
                QJsonObject i6=i5[i].toObject();
                QJsonValue i7=i6["agentiaId"].toInt();
                stash_M[0]=QString::number(i7.toInt());

                QJsonValue i8=i6["bottleCapacity"].toString();
                stash_M[1]=i8.toString();

                QJsonValue i9=i6["dose"].toString();
                stash_M[2]=i9.toString();

                QJsonValue i10=i6["expiryDate"].toString();
                stash_M[3]=i10.toString();

                QJsonValue i11=i6["drawerNo"].toInt();
                stash_M[4]=QString::number(i11.toInt());

                QJsonValue i12=i6["drawerName"].toString();
                stash_M[5]=i12.toString();

                QJsonValue i13=i6["positionNo"].toInt();
                stash_M[6]=QString::number(i13.toInt());

                QJsonValue i14=i6["positionName"].toString();
                stash_M[7]=i14.toString();

                QJsonValue i15=i6["positionId"].toInt();
                stash_M[8]=QString::number(i15.toInt());

                QJsonValue i16=i6["attribute"].toInt();
                stash_M[9]=QString::number(i16.toInt());

                query.prepare("insert into T_Task_return (agentiaId,bottleCapacity,dose,expiryDate,drawerNo,drawerName,positionNo,positionName,positionId,attribute) values (?,?,?,?,?,?,?,?,?,?)");
                query.addBindValue(stash_M[0]);
                query.addBindValue(stash_M[1]);
                query.addBindValue(stash_M[2]);
                query.addBindValue(stash_M[3]);
                query.addBindValue(stash_M[4]);
                query.addBindValue(stash_M[5]);
                query.addBindValue(stash_M[6]);
                query.addBindValue(stash_M[7]);
                query.addBindValue(stash_M[8]);
                query.addBindValue(stash_M[9]);
                query.exec();
                qDebug()<<"3  -----OK";
               }
//              query.exec(QString("select * from T_Task_return ORDER BY agentiaId DESC"));
          }
       }
}

void MainUI::on_pushButton_clicked()
{
    this->close();
}

